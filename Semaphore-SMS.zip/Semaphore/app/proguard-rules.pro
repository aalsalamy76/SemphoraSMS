# Sémaphore — règles R8
# Les Workers sont instanciés par réflexion par WorkManager.
-keep class * extends androidx.work.ListenableWorker { <init>(...); }
-keep class com.semaphore.sms.** { *; }

# Annotations de compilation référencées par certaines bibliothèques, absentes à l'exécution.
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**
