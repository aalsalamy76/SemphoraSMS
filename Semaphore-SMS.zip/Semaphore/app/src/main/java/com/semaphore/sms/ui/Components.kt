package com.semaphore.sms.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.semaphore.sms.data.Contacts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val avatarPalette = listOf(
    0xFF6366F1, 0xFF0EA5E9, 0xFF14B8A6, 0xFF22C55E, 0xFFF59E0B,
    0xFFEF4444, 0xFFEC4899, 0xFF8B5CF6, 0xFF06B6D4, 0xFF84CC16,
)

fun avatarColor(seed: String): Color = Color(avatarPalette[abs(seed.hashCode()) % avatarPalette.size])

@Composable
fun Avatar(name: String, photoUri: String?, size: Dp = 48.dp, group: Boolean = false) {
    val ctx = LocalContext.current
    val photo by produceState<ImageBitmap?>(initialValue = null, photoUri) {
        value = photoUri?.let { uri -> withContext(Dispatchers.IO) { Contacts.loadPhoto(ctx, uri)?.asImageBitmap() } }
    }
    val base = avatarColor(name)
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(base, base.copy(alpha = 0.75f)))),
        contentAlignment = Alignment.Center,
    ) {
        val p = photo
        val initials = Contacts.initials(name)
        when {
            p != null -> Image(bitmap = p, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            group -> Icon(Icons.Filled.Group, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
            initials.isNotEmpty() -> Text(initials, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.36f).sp)
            else -> Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
        }
    }
}

/** Image d'une pièce jointe MMS, décodée en arrière-plan à taille raisonnable. */
@Composable
fun MmsImage(uri: Uri, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b, contentDescription = "Image MMS", contentScale = ContentScale.Crop,
            modifier = modifier.widthIn(max = 240.dp).heightIn(max = 320.dp).clip(RoundedCornerShape(14.dp))
        )
    } else {
        Box(modifier.size(160.dp, 120.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(Locale.FRENCH),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 6.dp),
    )
}

@Composable
fun EmptyState(icon: ImageVector, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
    }
}

// ---------------------------------------------------------------------------------- Dates

object Fmt {
    private val fr = Locale.FRENCH

    private fun cal(t: Long) = Calendar.getInstance().apply { timeInMillis = t }

    private fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    fun time(t: Long): String = SimpleDateFormat("HH:mm", fr).format(Date(t))

    fun isSameDay(a: Long, b: Long) = sameDay(cal(a), cal(b))

    /** Horodatage compact de la liste des conversations. */
    fun short(t: Long): String {
        val now = cal(System.currentTimeMillis())
        val c = cal(t)
        if (sameDay(now, c)) return time(t)
        val y = cal(System.currentTimeMillis()).apply { add(Calendar.DAY_OF_YEAR, -1) }
        if (sameDay(y, c)) return "Hier"
        val diffDays = (System.currentTimeMillis() - t) / 86_400_000L
        if (diffDays in 0..6) return SimpleDateFormat("EEE", fr).format(Date(t))
        if (now.get(Calendar.YEAR) == c.get(Calendar.YEAR)) return SimpleDateFormat("d MMM", fr).format(Date(t))
        return SimpleDateFormat("dd/MM/yy", fr).format(Date(t))
    }

    /** Séparateur de jour dans une discussion. */
    fun day(t: Long): String {
        val now = cal(System.currentTimeMillis())
        val c = cal(t)
        if (sameDay(now, c)) return "Aujourd'hui"
        val y = cal(System.currentTimeMillis()).apply { add(Calendar.DAY_OF_YEAR, -1) }
        if (sameDay(y, c)) return "Hier"
        val pattern = if (now.get(Calendar.YEAR) == c.get(Calendar.YEAR)) "EEEE d MMMM" else "d MMMM yyyy"
        return SimpleDateFormat(pattern, fr).format(Date(t)).replaceFirstChar { it.uppercase() }
    }

    fun full(t: Long): String = SimpleDateFormat("EEEE d MMMM yyyy 'à' HH:mm", fr).format(Date(t))
        .replaceFirstChar { it.uppercase() }

    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes o"
        bytes < 1024 * 1024 -> "${bytes / 1024} Ko"
        else -> String.format(fr, "%.1f Mo", bytes / 1048576.0)
    }
}
