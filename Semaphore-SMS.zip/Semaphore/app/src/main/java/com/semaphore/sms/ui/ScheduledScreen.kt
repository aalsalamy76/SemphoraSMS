package com.semaphore.sms.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import com.semaphore.sms.data.Contacts
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.ScheduledSendWorker

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduledScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(AppPrefs(ctx).scheduled()) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Messages programmés") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        if (list.isEmpty()) {
            EmptyState(
                Icons.Filled.Schedule, "Aucun message programmé",
                "Dans une conversation, touchez l'horloge à côté du bouton d'envoi.",
                Modifier.padding(pad),
            )
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad)) {
                items(list, key = { it.id }) { s ->
                    ListItem(
                        overlineContent = { Text(Fmt.full(s.at)) },
                        headlineContent = { Text(Contacts.name(ctx, s.address)) },
                        supportingContent = { Text(s.body, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        leadingContent = { Avatar(Contacts.name(ctx, s.address), Contacts.photoUri(ctx, s.address)) },
                        trailingContent = {
                            IconButton(onClick = {
                                ScheduledSendWorker.cancel(ctx, s.id)
                                list = AppPrefs(ctx).scheduled()
                            }) { Icon(Icons.Filled.Close, "Annuler") }
                        },
                    )
                }
            }
        }
    }
}
