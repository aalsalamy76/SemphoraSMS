package com.semaphore.sms.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.util.LruCache
import java.util.concurrent.ConcurrentHashMap

/** Résolution des noms et photos de contacts, avec cache. */
object Contacts {
    private data class Entry(val name: String?, val photo: String?)

    private val cache = ConcurrentHashMap<String, Entry>()
    private val photos = LruCache<String, Bitmap>(64)

    fun invalidate() {
        cache.clear()
        photos.evictAll()
    }

    private fun lookup(ctx: Context, address: String): Entry {
        if (address.isBlank()) return Entry(null, null)
        cache[address]?.let { return it }
        var entry = Entry(null, null)
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
            ctx.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) entry = Entry(c.getString(0), c.getString(1))
            }
        } catch (e: Exception) {
            // Permission contacts refusée ou numéro non valide.
        }
        cache[address] = entry
        return entry
    }

    fun nameOrNull(ctx: Context, address: String): String? = lookup(ctx, address).name

    fun name(ctx: Context, address: String): String = lookup(ctx, address).name ?: formatNumber(address)

    fun photoUri(ctx: Context, address: String): String? = lookup(ctx, address).photo

    fun loadPhoto(ctx: Context, uri: String): Bitmap? {
        photos.get(uri)?.let { return it }
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
                ?.also { photos.put(uri, it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Recherche dans le carnet d'adresses (nom ou numéro). */
    fun search(ctx: Context, query: String, limit: Int = 30): List<ContactEntry> {
        val out = ArrayList<ContactEntry>()
        val seen = HashSet<String>()
        try {
            val sel: String?
            val args: Array<String>?
            if (query.isBlank()) {
                sel = null; args = null
            } else {
                sel = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
                args = arrayOf("%$query%", "%$query%")
            }
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
                ),
                sel, args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val name = c.getString(0) ?: continue
                    val number = c.getString(1) ?: continue
                    val key = name + "|" + number.filter { it.isDigit() || it == '+' }
                    if (!seen.add(key)) continue
                    out.add(ContactEntry(name, number, c.getString(2)))
                }
            }
        } catch (e: Exception) {
            // Permission refusée : liste vide.
        }
        return out
    }

    fun formatNumber(address: String): String {
        val d = address.filter { it.isDigit() || it == '+' }
        if (d.startsWith("+33") && d.length == 12) {
            return "+33 " + d.substring(3, 4) + " " + d.substring(4).chunked(2).joinToString(" ")
        }
        if (d.length == 10 && d.startsWith("0")) return d.chunked(2).joinToString(" ")
        return address
    }

    fun initials(name: String): String {
        if (name.isBlank()) return ""
        if (name.first().isDigit() || name.first() == '+') return ""
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val first = parts.firstOrNull()?.firstOrNull { it.isLetterOrDigit() }
        val last = if (parts.size > 1) parts.last().firstOrNull { it.isLetterOrDigit() } else null
        return listOfNotNull(first, last).joinToString("").uppercase()
    }
}
