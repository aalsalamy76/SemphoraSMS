package com.semaphore.sms.data

import android.net.Uri

data class Conversation(
    val threadId: Long,
    val addresses: List<String>,
    val displayName: String,
    val photoUri: String?,
    val snippet: String,
    val date: Long,
    val unreadCount: Int,
    val encrypted: Boolean,
) {
    val isGroup: Boolean get() = addresses.size > 1
    val mainAddress: String get() = addresses.firstOrNull() ?: ""
}

enum class MsgStatus { RECEIVED, SENDING, SENT, DELIVERED, FAILED }

data class Message(
    val id: Long,
    val isMms: Boolean,
    val threadId: Long,
    val address: String,
    val rawBody: String,
    val text: String,
    val encrypted: Boolean,
    val keyExchange: Boolean,
    val decryptFailed: Boolean,
    val date: Long,
    val outgoing: Boolean,
    val status: MsgStatus,
    val images: List<Uri> = emptyList(),
) {
    val uri: Uri get() = Uri.parse(if (isMms) "content://mms/$id" else "content://sms/$id")
}

data class SearchHit(
    val threadId: Long,
    val address: String,
    val displayName: String,
    val text: String,
    val date: Long,
)

data class ContactEntry(
    val name: String,
    val number: String,
    val photoUri: String?,
)

/** Constantes du fournisseur Telephony (valeurs stables de l'API Android). */
object Sms {
    const val TYPE_INBOX = 1
    const val TYPE_SENT = 2
    const val TYPE_DRAFT = 3
    const val TYPE_OUTBOX = 4
    const val TYPE_FAILED = 5
    const val TYPE_QUEUED = 6

    const val STATUS_NONE = -1
    const val STATUS_COMPLETE = 0
    const val STATUS_PENDING = 32
    const val STATUS_FAILED = 64

    val SMS: Uri = Uri.parse("content://sms")
    val INBOX: Uri = Uri.parse("content://sms/inbox")
    val OUTBOX: Uri = Uri.parse("content://sms/outbox")
    val MMS: Uri = Uri.parse("content://mms")
    val MMS_PART: Uri = Uri.parse("content://mms/part")
    val THREADS: Uri = Uri.parse("content://mms-sms/conversations?simple=true")
    val CANONICAL: Uri = Uri.parse("content://mms-sms/canonical-addresses")
    val MMS_SMS: Uri = Uri.parse("content://mms-sms/")

    fun threadUri(threadId: Long): Uri = Uri.parse("content://mms-sms/conversations/$threadId")
}
