package com.semaphore.sms.cloud

enum class CloudKind { S3, AZURE }

/**
 * Les 12 hébergeurs proposés. Tous reçoivent uniquement des fichiers déjà chiffrés sur le téléphone.
 * Les points d'accès sont pré-remplis avec une région européenne et restent modifiables.
 */
data class CloudProvider(
    val id: String,
    val name: String,
    val company: String,
    val country: String,
    val kind: CloudKind,
    val defaultEndpoint: String,
    val defaultRegion: String,
    val virtualHosted: Boolean,
    val bucketLabel: String,
    val accessKeyLabel: String,
    val secretKeyLabel: String,
    val help: String,
    val consoleUrl: String,
)

object CloudProviders {
    val all: List<CloudProvider> = listOf(
        CloudProvider(
            id = "aws", name = "Amazon S3", company = "Amazon Web Services", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.eu-west-3.amazonaws.com", defaultRegion = "eu-west-3",
            virtualHosted = true,
            bucketLabel = "Nom du bucket", accessKeyLabel = "Access Key ID", secretKeyLabel = "Secret Access Key",
            help = "Console AWS › IAM › Utilisateurs › Créer une clé d'accès. Donnez à l'utilisateur les droits " +
                "s3:PutObject, s3:GetObject, s3:ListBucket et s3:DeleteObject sur votre bucket. " +
                "Région par défaut : Paris (eu-west-3).",
            consoleUrl = "https://console.aws.amazon.com/s3/",
        ),
        CloudProvider(
            id = "azure", name = "Azure Blob Storage", company = "Microsoft Azure", country = "🇺🇸",
            kind = CloudKind.AZURE,
            defaultEndpoint = "https://<compte>.blob.core.windows.net/<conteneur>?<jeton SAS>", defaultRegion = "",
            virtualHosted = false,
            bucketLabel = "", accessKeyLabel = "", secretKeyLabel = "URL SAS du conteneur",
            help = "Portail Azure › Compte de stockage › Conteneurs › votre conteneur › Jetons d'accès partagé. " +
                "Cochez Lecture, Ajouter, Créer, Écrire, Supprimer et Lister, choisissez une date d'expiration " +
                "lointaine puis copiez l'« URL SAS d'objet blob ».",
            consoleUrl = "https://portal.azure.com/",
        ),
        CloudProvider(
            id = "gcs", name = "Google Cloud Storage", company = "Google Cloud", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://storage.googleapis.com", defaultRegion = "auto",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "ID de clé HMAC", secretKeyLabel = "Secret HMAC",
            help = "Console Google Cloud › Cloud Storage › Paramètres › Interopérabilité › Créer une clé HMAC " +
                "pour un compte de service ayant le rôle « Storage Object Admin » sur le bucket.",
            consoleUrl = "https://console.cloud.google.com/storage/settings;tab=interoperability",
        ),
        CloudProvider(
            id = "alibaba", name = "Object Storage Service (OSS)", company = "Alibaba Cloud", country = "🇨🇳",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.oss-eu-central-1.aliyuncs.com", defaultRegion = "eu-central-1",
            virtualHosted = true,
            bucketLabel = "Nom du bucket", accessKeyLabel = "AccessKey ID", secretKeyLabel = "AccessKey Secret",
            help = "Console Alibaba Cloud › RAM › Utilisateurs › Créer une AccessKey avec la stratégie " +
                "AliyunOSSFullAccess (ou limitée au bucket). Point d'accès compatible S3 : " +
                "s3.oss-<région>.aliyuncs.com (Francfort par défaut).",
            consoleUrl = "https://oss.console.aliyun.com/",
        ),
        CloudProvider(
            id = "oracle", name = "OCI Object Storage", company = "Oracle Cloud", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://<namespace>.compat.objectstorage.eu-paris-1.oraclecloud.com",
            defaultRegion = "eu-paris-1",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "Access Key", secretKeyLabel = "Secret Key",
            help = "Console OCI › Profil › Clés secrètes client › Générer une clé secrète. Remplacez <namespace> " +
                "par l'espace de noms Object Storage de votre location (visible dans Détails de la location).",
            consoleUrl = "https://cloud.oracle.com/object-storage/buckets",
        ),
        CloudProvider(
            id = "ibm", name = "Cloud Object Storage", company = "IBM Cloud", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.eu-de.cloud-object-storage.appdomain.cloud", defaultRegion = "eu-de",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "access_key_id (HMAC)", secretKeyLabel = "secret_access_key (HMAC)",
            help = "IBM Cloud › Cloud Object Storage › Données d'identification pour service › Nouvelle " +
                "donnée d'identification avec l'option « Inclure des données d'identification HMAC » (rôle Writer).",
            consoleUrl = "https://cloud.ibm.com/objectstorage",
        ),
        CloudProvider(
            id = "tencent", name = "Cloud Object Storage (COS)", company = "Tencent Cloud", country = "🇨🇳",
            kind = CloudKind.S3,
            defaultEndpoint = "https://cos.eu-frankfurt.myqcloud.com", defaultRegion = "eu-frankfurt",
            virtualHosted = true,
            bucketLabel = "Bucket (nom-APPID, ex. sauvegardes-1250000000)",
            accessKeyLabel = "SecretId", secretKeyLabel = "SecretKey",
            help = "Console Tencent Cloud › CAM › Clés API › Créer une clé. Le nom du bucket inclut votre APPID " +
                "(ex. sauvegardes-1250000000). Les buckets récents exigent l'adressage virtuel (laissé activé).",
            consoleUrl = "https://console.tencentcloud.com/cos",
        ),
        CloudProvider(
            id = "huawei", name = "Object Storage Service (OBS)", company = "Huawei Cloud", country = "🇨🇳",
            kind = CloudKind.S3,
            defaultEndpoint = "https://obs.eu-west-101.myhuaweicloud.eu", defaultRegion = "eu-west-101",
            virtualHosted = true,
            bucketLabel = "Nom du bucket", accessKeyLabel = "Access Key ID (AK)", secretKeyLabel = "Secret Access Key (SK)",
            help = "Console Huawei Cloud › Mes informations d'identification › Clés d'accès › Ajouter une clé. " +
                "Le point d'accès par défaut est la région européenne eu-west-101.",
            consoleUrl = "https://console.eu.huaweicloud.com/obs/",
        ),
        CloudProvider(
            id = "ovh", name = "Object Storage S3", company = "OVHcloud", country = "🇫🇷",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.gra.io.cloud.ovh.net", defaultRegion = "gra",
            virtualHosted = true,
            bucketLabel = "Nom du conteneur (bucket)", accessKeyLabel = "Access key", secretKeyLabel = "Secret key",
            help = "Espace client OVHcloud › Public Cloud › Object Storage › Utilisateurs S3 › Créer un utilisateur " +
                "puis « Voir les identifiants ». Hébergé en France (Gravelines par défaut, Paris : " +
                "s3.eu-west-par.io.cloud.ovh.net / eu-west-par).",
            consoleUrl = "https://www.ovh.com/manager/",
        ),
        CloudProvider(
            id = "r2", name = "R2", company = "Cloudflare", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://<account_id>.r2.cloudflarestorage.com", defaultRegion = "auto",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "Access Key ID", secretKeyLabel = "Secret Access Key",
            help = "Tableau de bord Cloudflare › R2 › Gérer les jetons d'API R2 › Créer un jeton (lecture et " +
                "écriture d'objets). Remplacez <account_id> par l'identifiant de compte affiché sur la page R2.",
            consoleUrl = "https://dash.cloudflare.com/?to=/:account/r2",
        ),
        CloudProvider(
            id = "b2", name = "B2 Cloud Storage", company = "Backblaze", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.eu-central-003.backblazeb2.com", defaultRegion = "eu-central-003",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "keyID", secretKeyLabel = "applicationKey",
            help = "Backblaze › Application Keys › Add a New Application Key (accès lecture/écriture au bucket). " +
                "Le point d'accès S3 du bucket est affiché dans la liste des buckets (« Endpoint »).",
            consoleUrl = "https://secure.backblaze.com/b2_buckets.htm",
        ),
        CloudProvider(
            id = "wasabi", name = "Hot Cloud Storage", company = "Wasabi", country = "🇺🇸",
            kind = CloudKind.S3,
            defaultEndpoint = "https://s3.eu-west-2.wasabisys.com", defaultRegion = "eu-west-2",
            virtualHosted = false,
            bucketLabel = "Nom du bucket", accessKeyLabel = "Access Key", secretKeyLabel = "Secret Key",
            help = "Console Wasabi › Access Keys › Create New Access Key. Région par défaut : Paris (eu-west-2).",
            consoleUrl = "https://console.wasabisys.com/",
        ),
    )

    fun byId(id: String): CloudProvider? = all.firstOrNull { it.id == id }
}
