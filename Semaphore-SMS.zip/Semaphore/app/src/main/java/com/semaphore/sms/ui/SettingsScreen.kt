package com.semaphore.sms.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.biometric.BiometricManager
import com.semaphore.sms.BuildConfig
import com.semaphore.sms.UiState
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.prefs.AppPrefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onBackup: () -> Unit,
    onScheduled: () -> Unit,
    onRequestDefault: () -> Unit,
) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    var appLock by remember { mutableStateOf(prefs.appLock) }
    var hidePreviews by remember { mutableStateOf(prefs.hidePreviews) }
    var showKey by remember { mutableStateOf(false) }
    var confirmRegen by remember { mutableStateOf(false) }
    var lockError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Réglages") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())) {
            SectionHeader("Général")
            ListItem(
                headlineContent = { Text("Application SMS par défaut") },
                supportingContent = { Text(if (UiState.isDefaultSms) "Sémaphore est votre application SMS ✓" else "Touchez pour définir Sémaphore par défaut") },
                leadingContent = { Icon(Icons.Filled.Sms, null) },
                modifier = Modifier.clickable(enabled = !UiState.isDefaultSms) { onRequestDefault() },
            )
            ListItem(
                headlineContent = { Text("Notifications") },
                supportingContent = { Text("Son, vibration, affichage sur l'écran de verrouillage") },
                leadingContent = { Icon(Icons.Filled.Notifications, null) },
                modifier = Modifier.clickable {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                },
            )
            ListItem(
                headlineContent = { Text("Messages programmés") },
                supportingContent = { Text("${prefs.scheduled().size} en attente") },
                leadingContent = { Icon(Icons.Filled.Schedule, null) },
                modifier = Modifier.clickable { onScheduled() },
            )

            SectionHeader("Apparence")
            ListItem(
                headlineContent = { Text("Thème") },
                leadingContent = { Icon(Icons.Filled.Palette, null) },
                supportingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                        listOf("Système", "Clair", "Sombre").forEachIndexed { i, label ->
                            FilterChip(
                                selected = UiState.themeMode == i,
                                onClick = { UiState.themeMode = i; prefs.themeMode = i },
                                label = { Text(label) },
                            )
                        }
                    }
                },
            )

            SectionHeader("Sécurité et confidentialité")
            ListItem(
                headlineContent = { Text("Verrouillage de l'application") },
                supportingContent = { Text(lockError ?: "Empreinte, visage ou code du téléphone à l'ouverture") },
                leadingContent = { Icon(Icons.Filled.Fingerprint, null) },
                trailingContent = {
                    Switch(checked = appLock, onCheckedChange = { v ->
                        val can = BiometricManager.from(ctx).canAuthenticate(
                            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                        )
                        if (v && can != BiometricManager.BIOMETRIC_SUCCESS) {
                            lockError = "Configurez d'abord un verrouillage d'écran sur le téléphone"
                        } else {
                            lockError = null
                            appLock = v; prefs.appLock = v
                        }
                    })
                },
            )
            ListItem(
                headlineContent = { Text("Masquer le contenu des notifications") },
                supportingContent = { Text("Affiche « Nouveau message » au lieu du texte") },
                leadingContent = { Icon(Icons.Filled.VisibilityOff, null) },
                trailingContent = {
                    Switch(checked = hidePreviews, onCheckedChange = { hidePreviews = it; prefs.hidePreviews = it })
                },
            )
            ListItem(
                headlineContent = { Text("Ma clé de chiffrement") },
                supportingContent = { Text("Empreinte de votre identité E2E") },
                leadingContent = { Icon(Icons.Filled.VpnKey, null) },
                modifier = Modifier.clickable { showKey = true },
            )
            ListItem(
                headlineContent = { Text("Numéros bloqués") },
                supportingContent = { Text("Liste de blocage du système Android") },
                leadingContent = { Icon(Icons.Filled.Block, null) },
                modifier = Modifier.clickable {
                    try {
                        val tm = ctx.getSystemService(android.telecom.TelecomManager::class.java)
                        ctx.startActivity(tm.createManageBlockedNumbersIntent())
                    } catch (e: Exception) {
                    }
                },
            )

            SectionHeader("Sauvegarde")
            ListItem(
                headlineContent = { Text("Sauvegarde chiffrée et cloud") },
                supportingContent = {
                    Text(prefs.lastBackupSummary.ifEmpty { "12 hébergeurs · chiffrement AES-256 avant envoi" })
                },
                leadingContent = { Icon(Icons.Filled.CloudUpload, null) },
                modifier = Modifier.clickable { onBackup() },
            )

            SectionHeader("À propos")
            ListItem(
                headlineContent = { Text("Sémaphore ${BuildConfig.VERSION_NAME}") },
                supportingContent = {
                    Text("SMS chiffrés de bout en bout entre utilisateurs de Sémaphore, sauvegardes zero-knowledge vers 12 clouds.")
                },
                leadingContent = { Icon(Icons.Filled.Info, null) },
            )
        }
    }

    if (showKey) {
        AlertDialog(
            onDismissRequest = { showKey = false },
            icon = { Icon(Icons.Filled.VpnKey, null) },
            title = { Text("Ma clé de chiffrement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Empreinte (à comparer avec vos contacts) :")
                    SelectionContainer {
                        Text(remember { E2E.myFingerprint(ctx) }, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleSmall)
                    }
                    Text(
                        "La clé privée est générée sur ce téléphone et protégée par le Keystore Android. Elle ne " +
                            "quitte l'appareil qu'à l'intérieur de vos sauvegardes, chiffrées par votre phrase secrète.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showKey = false }) { Text("Fermer") } },
            dismissButton = { TextButton(onClick = { showKey = false; confirmRegen = true }) { Text("Régénérer…") } },
        )
    }

    if (confirmRegen) {
        AlertDialog(
            onDismissRequest = { confirmRegen = false },
            title = { Text("Régénérer la clé ?") },
            text = {
                Text(
                    "Vos contacts devront recevoir votre nouvelle clé (renvoyez-la depuis chaque conversation). " +
                        "L'ancienne clé est conservée uniquement pour relire vos anciens messages."
                )
            },
            confirmButton = {
                TextButton(onClick = { E2E.regenerateIdentity(ctx); confirmRegen = false }) { Text("Régénérer") }
            },
            dismissButton = { TextButton(onClick = { confirmRegen = false }) { Text("Annuler") } },
        )
    }
}
