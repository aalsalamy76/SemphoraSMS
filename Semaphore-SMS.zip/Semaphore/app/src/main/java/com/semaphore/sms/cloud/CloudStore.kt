package com.semaphore.sms.cloud

import android.content.Context
import com.semaphore.sms.prefs.AppPrefs
import org.json.JSONObject

/** Stockage des configurations cloud, entièrement chiffrées par le Keystore Android. */
object CloudStore {
    private fun key(id: String) = "cloud_$id"

    fun load(ctx: Context, id: String): CloudConfig {
        val provider = CloudProviders.byId(id)
        val default = CloudConfig(
            providerId = id,
            endpoint = provider?.defaultEndpoint ?: "",
            region = provider?.defaultRegion ?: "",
            virtualHosted = provider?.virtualHosted ?: false,
        )
        val json = AppPrefs(ctx).getSecret(key(id)) ?: return default
        return try {
            val o = JSONObject(json)
            CloudConfig(
                providerId = id,
                enabled = o.optBoolean("enabled", false),
                endpoint = o.optString("endpoint", default.endpoint),
                region = o.optString("region", default.region),
                bucket = o.optString("bucket", ""),
                accessKey = o.optString("accessKey", ""),
                secretKey = o.optString("secretKey", ""),
                prefix = o.optString("prefix", default.prefix),
                virtualHosted = o.optBoolean("virtualHosted", default.virtualHosted),
                lastStatus = o.optString("lastStatus", ""),
                lastOk = o.optBoolean("lastOk", false),
                lastAt = o.optLong("lastAt", 0L),
            )
        } catch (e: Exception) {
            default
        }
    }

    fun save(ctx: Context, cfg: CloudConfig) {
        val o = JSONObject()
            .put("enabled", cfg.enabled)
            .put("endpoint", cfg.endpoint.trim())
            .put("region", cfg.region.trim())
            .put("bucket", cfg.bucket.trim())
            .put("accessKey", cfg.accessKey.trim())
            .put("secretKey", cfg.secretKey.trim())
            .put("prefix", cfg.prefix.trim())
            .put("virtualHosted", cfg.virtualHosted)
            .put("lastStatus", cfg.lastStatus)
            .put("lastOk", cfg.lastOk)
            .put("lastAt", cfg.lastAt)
        AppPrefs(ctx).putSecret(key(cfg.providerId), o.toString())
    }

    fun remove(ctx: Context, id: String) = AppPrefs(ctx).putSecret(key(id), null)

    fun all(ctx: Context): List<CloudConfig> = CloudProviders.all.map { load(ctx, it.id) }

    fun recordResult(ctx: Context, id: String, ok: Boolean, status: String) {
        save(ctx, load(ctx, id).copy(lastOk = ok, lastStatus = status, lastAt = System.currentTimeMillis()))
    }
}
