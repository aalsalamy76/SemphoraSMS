package com.semaphore.sms.ui

import android.app.Application
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.data.Contacts
import com.semaphore.sms.data.Conversation
import com.semaphore.sms.data.Message
import com.semaphore.sms.data.SearchHit
import com.semaphore.sms.data.Sms
import com.semaphore.sms.data.SmsRepository
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.prefs.ScheduledMessage
import com.semaphore.sms.sms.Notifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Observe le fournisseur SMS et déclenche `onChange` (avec anti-rebond). */
private class SmsObserver(private val callback: () -> Unit) : ContentObserver(Handler(Looper.getMainLooper())) {
    override fun onChange(selfChange: Boolean) {
        callback()
    }
}

class ConversationsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SmsRepository(app)
    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading
    private val _hits = MutableStateFlow<List<SearchHit>>(emptyList())
    val hits: StateFlow<List<SearchHit>> = _hits

    private var reloadJob: Job? = null
    private var searchJob: Job? = null
    private val observer = SmsObserver { reload() }

    init {
        try {
            app.contentResolver.registerContentObserver(Sms.MMS_SMS, true, observer)
            app.contentResolver.registerContentObserver(Sms.SMS, true, observer)
        } catch (e: Exception) {
        }
        reload(immediate = true)
    }

    fun reload(immediate: Boolean = false) {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch {
            if (!immediate) delay(250)
            val list = withContext(Dispatchers.IO) { repo.loadConversations() }
            _conversations.value = list
            _loading.value = false
        }
    }

    fun search(query: String) {
        searchJob?.cancel()
        if (query.length < 2) {
            _hits.value = emptyList(); return
        }
        searchJob = viewModelScope.launch {
            delay(250)
            _hits.value = withContext(Dispatchers.IO) { repo.search(query) }
        }
    }

    fun markRead(c: Conversation) = viewModelScope.launch(Dispatchers.IO) {
        repo.markThreadRead(c.threadId)
        Notifications.cancel(getApplication(), c.threadId)
    }

    fun delete(c: Conversation) = viewModelScope.launch(Dispatchers.IO) {
        repo.deleteThread(c.threadId)
        Notifications.cancel(getApplication(), c.threadId)
        reload()
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
    }
}

data class E2EInfo(
    val peerKnown: Boolean = false,
    val enabled: Boolean = false,
    val keyChanged: Boolean = false,
    val verified: Boolean = false,
    val safetyNumber: String? = null,
    val myFingerprint: String = "",
)

class ThreadViewModel(
    app: Application,
    initialThreadId: Long,
    initialAddress: String,
) : AndroidViewModel(app) {
    private val repo = SmsRepository(app)
    private val ctx = app

    var threadId: Long = initialThreadId
        private set

    private val _addresses = MutableStateFlow(if (initialAddress.isBlank()) emptyList() else listOf(initialAddress))
    val addresses: StateFlow<List<String>> = _addresses
    private val _title = MutableStateFlow(if (initialAddress.isBlank()) "" else Contacts.formatNumber(initialAddress))
    val title: StateFlow<String> = _title
    private val _photo = MutableStateFlow<String?>(null)
    val photo: StateFlow<String?> = _photo
    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages
    private val _e2e = MutableStateFlow(E2EInfo())
    val e2e: StateFlow<E2EInfo> = _e2e
    private val _scheduled = MutableStateFlow<List<ScheduledMessage>>(emptyList())
    val scheduled: StateFlow<List<ScheduledMessage>> = _scheduled
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading

    private var job: Job? = null
    private val observer = SmsObserver { reload() }

    val mainAddress: String get() = _addresses.value.firstOrNull() ?: ""

    init {
        try {
            app.contentResolver.registerContentObserver(Sms.MMS_SMS, true, observer)
            app.contentResolver.registerContentObserver(Sms.SMS, true, observer)
        } catch (e: Exception) {
        }
        reload(immediate = true)
    }

    fun reload(immediate: Boolean = false) {
        job?.cancel()
        job = viewModelScope.launch {
            if (!immediate) delay(200)
            withContext(Dispatchers.IO) {
                if (threadId <= 0 && mainAddress.isNotBlank()) threadId = repo.threadIdFor(mainAddress)
                if (threadId > 0) {
                    val addrs = repo.threadAddresses(threadId)
                    if (addrs.isNotEmpty()) _addresses.value = addrs
                }
                val addrs = _addresses.value
                val main = addrs.firstOrNull() ?: ""
                _title.value = if (addrs.size > 1) addrs.joinToString(", ") { Contacts.nameOrNull(ctx, it) ?: Contacts.formatNumber(it) }
                else Contacts.name(ctx, main)
                _photo.value = if (addrs.size == 1) Contacts.photoUri(ctx, main) else null
                _messages.value = if (threadId > 0) repo.loadMessages(threadId, main) else emptyList()
                refreshE2E()
                refreshScheduled()
                if (threadId > 0) {
                    repo.markThreadRead(threadId)
                    Notifications.cancel(ctx, threadId)
                }
            }
            _loading.value = false
        }
    }

    fun refreshE2E() {
        val main = mainAddress
        if (main.isBlank() || _addresses.value.size > 1) {
            _e2e.value = E2EInfo(); return
        }
        val prefs = AppPrefs(ctx)
        val nk = E2E.numberKey(main)
        _e2e.value = E2EInfo(
            peerKnown = prefs.peerKey(nk) != null,
            enabled = prefs.e2eEnabled(nk),
            keyChanged = prefs.keyChanged(nk),
            verified = prefs.keyVerified(nk),
            safetyNumber = try { E2E.safetyNumber(ctx, main) } catch (e: Exception) { null },
            myFingerprint = try { E2E.myFingerprint(ctx) } catch (e: Exception) { "" },
        )
    }

    fun refreshScheduled() {
        val keys = _addresses.value.map { E2E.numberKey(it) }.toSet()
        _scheduled.value = AppPrefs(ctx).scheduled().filter { E2E.numberKey(it.address) in keys }
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
    }
}
