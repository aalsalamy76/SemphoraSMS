package com.semaphore.sms

import android.app.Application
import android.content.Context
import android.provider.Telephony
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.Notifications

class SemaphoreApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        Thread { try { E2E.ensureIdentity(this) } catch (e: Exception) { } }.start()
    }
}

/** État d'interface partagé (observé par Compose). */
object UiState {
    var themeMode by mutableIntStateOf(0)
    var isDefaultSms by mutableStateOf(false)
    /** Incrémenté à chaque retour au premier plan / changement de permissions pour recharger les listes. */
    var refreshTick by mutableIntStateOf(0)

    fun init(ctx: Context) {
        themeMode = AppPrefs(ctx).themeMode
        refresh(ctx)
    }

    fun refresh(ctx: Context) {
        isDefaultSms = try {
            Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName
        } catch (e: Exception) {
            false
        }
        refreshTick++
    }
}
