package com.semaphore.sms.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.BlockedNumberContract
import android.provider.Telephony
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.crypto.E2ECore
import com.semaphore.sms.data.Contacts
import com.semaphore.sms.data.SmsRepository
import com.semaphore.sms.prefs.AppPrefs

/** Réception des SMS (diffusé uniquement à l'application SMS par défaut). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_DELIVER") return
        val messages = try {
            Telephony.Sms.Intents.getMessagesFromIntent(intent)
        } catch (e: Exception) {
            null
        } ?: return
        if (messages.isEmpty()) return
        val subId = intent.getIntExtra("subscription", -1)
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                // Un long SMS arrive en plusieurs fragments : on les recolle par expéditeur.
                val grouped = LinkedHashMap<String, StringBuilder>()
                var sentAt = System.currentTimeMillis()
                for (m in messages) {
                    if (m == null) continue
                    val addr = m.displayOriginatingAddress ?: m.originatingAddress ?: continue
                    grouped.getOrPut(addr) { StringBuilder() }.append(m.displayMessageBody ?: m.messageBody ?: "")
                    sentAt = m.timestampMillis
                }
                for ((addr, body) in grouped) IncomingHandler.handle(app, addr, body.toString(), sentAt, subId)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

object IncomingHandler {
    fun handle(ctx: Context, address: String, body: String, sentAt: Long, subId: Int) {
        if (isBlocked(ctx, address)) return
        val prefs = AppPrefs(ctx)
        val nk = E2E.numberKey(address)

        if (E2ECore.isKeyMessage(body)) {
            val key = E2ECore.parseKeyMessage(body)
            if (key != null) {
                val b64 = E2ECore.b64(key)
                val old = prefs.peerKey(nk)
                val changed = old != null && old != b64
                if (changed) {
                    prefs.addPeerKeyHistory(nk, old!!)
                    prefs.setKeyChanged(nk, true)
                    prefs.setKeyVerified(nk, false)
                }
                prefs.setPeerKey(nk, b64)
                // On répond avec notre clé si le contact ne l'a pas encore (ou vient d'en changer),
                // au plus une fois toutes les 10 minutes par numéro (anti-abus : pas de SMS en rafale).
                val now = System.currentTimeMillis()
                val lastReply = prefs.getRaw("keyreply_$nk")?.toLongOrNull() ?: 0L
                if ((!prefs.keySent(nk) || changed) && now - lastReply > 10 * 60_000L) {
                    SmsSender.sendRaw(ctx, address, E2E.keyMessage(ctx))
                    prefs.setKeySent(nk, true)
                    prefs.putRaw("keyreply_$nk", now.toString())
                }
            }
        }

        val repo = SmsRepository(ctx)
        repo.insertIncoming(address, body, sentAt, subId)
        Contacts.invalidate()
        if (!E2ECore.isKeyMessage(body)) {
            val threadId = repo.threadIdFor(address)
            Notifications.showIncoming(ctx, address, threadId)
        }
    }

    fun isBlocked(ctx: Context, address: String): Boolean = try {
        BlockedNumberContract.isBlocked(ctx, address)
    } catch (e: Exception) {
        false
    }
}
