package com.semaphore.sms.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.semaphore.sms.data.ContactEntry
import com.semaphore.sms.data.Contacts
import com.semaphore.sms.data.SmsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Choix du destinataire d'un nouveau message (contacts ou numéro saisi). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewMessageScreen(
    initialTo: String,
    onBack: () -> Unit,
    onOpenThread: (threadId: Long, address: String) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf(initialTo) }
    var dialpad by rememberSaveable { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<ContactEntry>>(emptyList()) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(query) {
        delay(150)
        results = withContext(Dispatchers.IO) { Contacts.search(ctx, query) }
    }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }

    fun open(address: String) {
        val a = address.trim()
        if (a.isEmpty()) return
        scope.launch {
            val tid = withContext(Dispatchers.IO) { SmsRepository(ctx).threadIdFor(a) }
            onOpenThread(tid, a)
        }
    }

    val typedNumber = query.trim().takeIf { q -> q.isNotEmpty() && q.all { it.isDigit() || it in "+ ()-." } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nouveau message") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("À :") },
                placeholder = { Text("Nom ou numéro") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Person, null) },
                trailingIcon = {
                    IconButton(onClick = { dialpad = !dialpad }) { Icon(Icons.Filled.Dialpad, "Clavier numérique") }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (dialpad) KeyboardType.Phone else KeyboardType.Text,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = KeyboardActions(onNext = { typedNumber?.let { open(it) } }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focus),
            )
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                if (typedNumber != null) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().clickable { open(typedNumber) }.padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Avatar(typedNumber, null, size = 44.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Envoyer à ${Contacts.formatNumber(typedNumber)}", style = MaterialTheme.typography.titleSmall)
                                Text("Numéro saisi", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                        }
                    }
                }
                if (results.isNotEmpty()) item { SectionHeader("Contacts") }
                items(results, key = { it.name + "|" + it.number }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { open(c.number) }.padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(c.name, c.photoUri, size = 44.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(c.name, style = MaterialTheme.typography.titleSmall)
                            Text(Contacts.formatNumber(c.number), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
