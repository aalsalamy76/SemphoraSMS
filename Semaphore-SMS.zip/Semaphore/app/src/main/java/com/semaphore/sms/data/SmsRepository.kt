package com.semaphore.sms.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.Telephony
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.crypto.E2ECore

/** Accès au fournisseur de messages Android (SMS + lecture des MMS). */
class SmsRepository(context: Context) {
    private val ctx = context.applicationContext
    private val cr = ctx.contentResolver

    // ------------------------------------------------------------------ Conversations

    private fun canonicalAddresses(): Map<Long, String> {
        val map = HashMap<Long, String>()
        try {
            cr.query(Sms.CANONICAL, arrayOf("_id", "address"), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val addr = c.getString(1) ?: continue
                    map[c.getLong(0)] = addr
                }
            }
        } catch (e: Exception) {
        }
        return map
    }

    private fun unreadCounts(): Map<Long, Int> {
        val map = HashMap<Long, Int>()
        try {
            cr.query(Sms.INBOX, arrayOf("thread_id"), "read = 0", null, null)?.use { c ->
                while (c.moveToNext()) {
                    val t = c.getLong(0)
                    map[t] = (map[t] ?: 0) + 1
                }
            }
        } catch (e: Exception) {
        }
        try {
            cr.query(Sms.MMS, arrayOf("thread_id"), "read = 0 AND msg_box = 1", null, null)?.use { c ->
                while (c.moveToNext()) {
                    val t = c.getLong(0)
                    map[t] = (map[t] ?: 0) + 1
                }
            }
        } catch (e: Exception) {
        }
        return map
    }

    fun loadConversations(): List<Conversation> {
        val canon = canonicalAddresses()
        val unread = unreadCounts()
        val out = ArrayList<Conversation>()
        try {
            cr.query(
                Sms.THREADS,
                arrayOf("_id", "date", "snippet", "recipient_ids", "message_count"),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val threadId = c.getLong(0)
                    if (c.getInt(4) == 0) continue
                    val ids = (c.getString(3) ?: "").split(" ").mapNotNull { it.trim().toLongOrNull() }
                    val addresses = ids.mapNotNull { canon[it] }
                    if (addresses.isEmpty()) continue
                    val main = addresses.first()
                    val name = if (addresses.size == 1) Contacts.name(ctx, main)
                    else addresses.joinToString(", ") { Contacts.nameOrNull(ctx, it) ?: Contacts.formatNumber(it) }
                    val rawSnippet = c.getString(2) ?: ""
                    val snippet = when {
                        E2ECore.isKeyMessage(rawSnippet) -> "🔑 Clés de chiffrement échangées"
                        E2ECore.isEncrypted(rawSnippet) ->
                            E2E.decryptFrom(ctx, main, rawSnippet)?.let { "🔒 $it" } ?: "🔒 Message chiffré"
                        rawSnippet.isBlank() -> "📎 Pièce jointe"
                        else -> rawSnippet
                    }
                    out.add(
                        Conversation(
                            threadId = threadId,
                            addresses = addresses,
                            displayName = name,
                            photoUri = if (addresses.size == 1) Contacts.photoUri(ctx, main) else null,
                            snippet = snippet.replace('\n', ' '),
                            date = c.getLong(1),
                            unreadCount = unread[threadId] ?: 0,
                            encrypted = addresses.size == 1 && E2E.isActive(ctx, main),
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun threadAddresses(threadId: Long): List<String> {
        val canon = canonicalAddresses()
        try {
            cr.query(Sms.THREADS, arrayOf("_id", "recipient_ids"), "_id = ?", arrayOf(threadId.toString()), null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        return (c.getString(1) ?: "").split(" ")
                            .mapNotNull { it.trim().toLongOrNull() }
                            .mapNotNull { canon[it] }
                    }
                }
        } catch (e: Exception) {
        }
        // Repli : adresse du dernier SMS du fil.
        try {
            cr.query(Sms.SMS, arrayOf("address"), "thread_id = ?", arrayOf(threadId.toString()), "date DESC")
                ?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { return listOf(it) } }
        } catch (e: Exception) {
        }
        return emptyList()
    }

    fun threadIdFor(address: String): Long =
        try {
            Telephony.Threads.getOrCreateThreadId(ctx, address)
        } catch (e: Exception) {
            0L
        }

    // ------------------------------------------------------------------ Messages

    fun loadMessages(threadId: Long, fallbackAddress: String, limit: Int = 800): List<Message> {
        val out = ArrayList<Message>()
        try {
            cr.query(
                Sms.SMS,
                arrayOf("_id", "address", "body", "date", "type", "status"),
                "thread_id = ?", arrayOf(threadId.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val type = c.getInt(4)
                    if (type == Sms.TYPE_DRAFT) continue
                    val address = c.getString(1) ?: fallbackAddress
                    val raw = c.getString(2) ?: ""
                    val dt = E2E.displayText(ctx, address, raw)
                    val outgoing = type != Sms.TYPE_INBOX
                    val status = when (type) {
                        Sms.TYPE_INBOX -> MsgStatus.RECEIVED
                        Sms.TYPE_OUTBOX, Sms.TYPE_QUEUED -> MsgStatus.SENDING
                        Sms.TYPE_FAILED -> MsgStatus.FAILED
                        else -> {
                            val st = c.getInt(5)
                            when {
                                st == Sms.STATUS_COMPLETE -> MsgStatus.DELIVERED
                                st >= Sms.STATUS_FAILED -> MsgStatus.FAILED
                                else -> MsgStatus.SENT
                            }
                        }
                    }
                    out.add(
                        Message(
                            id = c.getLong(0), isMms = false, threadId = threadId, address = address,
                            rawBody = raw, text = dt.text, encrypted = dt.encrypted,
                            keyExchange = dt.keyExchange, decryptFailed = dt.failed,
                            date = c.getLong(3), outgoing = outgoing, status = status,
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        out.addAll(loadMms(threadId, fallbackAddress, limit))
        out.sortByDescending { it.date }
        return if (out.size > limit) out.subList(0, limit).toList() else out
    }

    private fun loadMms(threadId: Long, fallbackAddress: String, limit: Int): List<Message> {
        val out = ArrayList<Message>()
        try {
            cr.query(
                Sms.MMS, arrayOf("_id", "date", "msg_box"),
                "thread_id = ?", arrayOf(threadId.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val id = c.getLong(0)
                    val box = c.getInt(2)
                    val outgoing = box != 1
                    val texts = ArrayList<String>()
                    val images = ArrayList<Uri>()
                    cr.query(Sms.MMS_PART, arrayOf("_id", "ct", "text"), "mid = ?", arrayOf(id.toString()), null)
                        ?.use { p ->
                            while (p.moveToNext()) {
                                val ct = p.getString(1) ?: ""
                                when {
                                    ct == "text/plain" -> p.getString(2)?.let { texts.add(it) }
                                    ct.startsWith("image/") -> images.add(Uri.parse("content://mms/part/${p.getLong(0)}"))
                                }
                            }
                        }
                    val from = if (outgoing) fallbackAddress else mmsSender(id) ?: fallbackAddress
                    val status = when (box) {
                        1 -> MsgStatus.RECEIVED
                        4 -> MsgStatus.SENDING
                        5 -> MsgStatus.FAILED
                        else -> MsgStatus.SENT
                    }
                    out.add(
                        Message(
                            id = id, isMms = true, threadId = threadId, address = from,
                            rawBody = texts.joinToString("\n"), text = texts.joinToString("\n"),
                            encrypted = false, keyExchange = false, decryptFailed = false,
                            date = c.getLong(1) * 1000L, outgoing = outgoing, status = status, images = images,
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun mmsSender(mmsId: Long): String? = try {
        cr.query(Uri.parse("content://mms/$mmsId/addr"), arrayOf("address"), "type = 137", null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    fun search(query: String, limit: Int = 60): List<SearchHit> {
        if (query.length < 2) return emptyList()
        val out = ArrayList<SearchHit>()
        try {
            cr.query(
                Sms.SMS, arrayOf("thread_id", "address", "body", "date"),
                "body LIKE ?", arrayOf("%$query%"), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val addr = c.getString(1) ?: ""
                    out.add(SearchHit(c.getLong(0), addr, Contacts.name(ctx, addr), c.getString(2) ?: "", c.getLong(3)))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    // ------------------------------------------------------------------ Écriture

    fun insertIncoming(address: String, body: String, sentAt: Long, subId: Int): Uri? {
        val values = ContentValues().apply {
            put("address", address)
            put("body", body)
            put("date", System.currentTimeMillis())
            put("date_sent", sentAt)
            put("read", 0)
            put("seen", 0)
            put("type", Sms.TYPE_INBOX)
            val t = threadIdFor(address)
            if (t > 0) put("thread_id", t)
            if (subId >= 0) put("sub_id", subId)
        }
        return try {
            cr.insert(Sms.INBOX, values)
        } catch (e: Exception) {
            null
        }
    }

    fun insertOutgoing(address: String, body: String): Uri? {
        val values = ContentValues().apply {
            put("address", address)
            put("body", body)
            put("date", System.currentTimeMillis())
            put("read", 1)
            put("seen", 1)
            put("type", Sms.TYPE_OUTBOX)
            put("status", Sms.STATUS_PENDING)
            val t = threadIdFor(address)
            if (t > 0) put("thread_id", t)
        }
        return try {
            cr.insert(Sms.OUTBOX, values)
        } catch (e: Exception) {
            null
        }
    }

    fun setType(uri: Uri, type: Int) {
        try {
            cr.update(uri, ContentValues().apply { put("type", type) }, null, null)
        } catch (e: Exception) {
        }
    }

    fun setStatus(uri: Uri, status: Int) {
        try {
            cr.update(uri, ContentValues().apply { put("status", status) }, null, null)
        } catch (e: Exception) {
        }
    }

    fun markThreadRead(threadId: Long) {
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        try {
            cr.update(Sms.SMS, v, "thread_id = ? AND (read = 0 OR seen = 0)", arrayOf(threadId.toString()))
        } catch (e: Exception) {
        }
        try {
            cr.update(Sms.MMS, v, "thread_id = ? AND read = 0", arrayOf(threadId.toString()))
        } catch (e: Exception) {
        }
    }

    fun deleteMessage(message: Message): Boolean = try {
        cr.delete(message.uri, null, null) > 0
    } catch (e: Exception) {
        false
    }

    fun deleteThread(threadId: Long): Boolean = try {
        cr.delete(Sms.threadUri(threadId), null, null) > 0
    } catch (e: Exception) {
        false
    }

    /** Messages non lus d'un fil (pour la notification). */
    fun unreadInThread(threadId: Long, limit: Int = 6): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        try {
            cr.query(
                Sms.INBOX, arrayOf("address", "body", "date"),
                "thread_id = ? AND read = 0", arrayOf(threadId.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) {
                    val addr = c.getString(0) ?: ""
                    val dt = E2E.displayText(ctx, addr, c.getString(1))
                    out.add(dt.text to c.getLong(2))
                }
            }
        } catch (e: Exception) {
        }
        return out.reversed()
    }
}
