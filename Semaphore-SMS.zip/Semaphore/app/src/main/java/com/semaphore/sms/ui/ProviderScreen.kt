package com.semaphore.sms.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.semaphore.sms.UiState
import com.semaphore.sms.backup.CloudBackup
import com.semaphore.sms.cloud.CloudKind
import com.semaphore.sms.cloud.CloudProviders
import com.semaphore.sms.cloud.CloudStore
import com.semaphore.sms.cloud.RemoteFile
import com.semaphore.sms.crypto.BackupCrypto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Configuration d'un hébergeur, test de connexion et restauration depuis le cloud. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProviderScreen(providerId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val provider = remember(providerId) { CloudProviders.byId(providerId) }
    if (provider == null) {
        androidx.compose.runtime.LaunchedEffect(Unit) { onBack() }
        return
    }
    val initial = remember(providerId) { CloudStore.load(ctx, providerId) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var enabled by remember { mutableStateOf(initial.enabled) }
    var endpoint by remember { mutableStateOf(initial.endpoint) }
    var region by remember { mutableStateOf(initial.region) }
    var bucket by remember { mutableStateOf(initial.bucket) }
    var accessKey by remember { mutableStateOf(initial.accessKey) }
    var secretKey by remember { mutableStateOf(initial.secretKey) }
    var prefix by remember { mutableStateOf(initial.prefix) }
    var virtualHosted by remember { mutableStateOf(initial.virtualHosted) }
    var showSecret by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }
    var files by remember { mutableStateOf<List<RemoteFile>?>(null) }
    var restoreTarget by remember { mutableStateOf<RemoteFile?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    val isAzure = provider.kind == CloudKind.AZURE

    fun current() = initial.copy(
        enabled = enabled, endpoint = endpoint.trim(), region = region.trim(), bucket = bucket.trim(),
        accessKey = accessKey.trim(), secretKey = secretKey.trim(), prefix = prefix.trim(), virtualHosted = virtualHosted,
    )

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun save(silent: Boolean = false): Boolean {
        val cfg = current()
        val err = cfg.validationError()
        if (err != null && cfg.enabled) {
            toast(err); return false
        }
        CloudStore.save(ctx, cfg)
        UiState.refreshTick++
        if (!silent) toast(if (err == null) "Enregistré" else "Enregistré (incomplet : $err)")
        return err == null
    }

    fun runAction(label: String, block: suspend () -> String) {
        if (busy != null) return
        busy = label
        scope.launch {
            val msg = try {
                block()
            } catch (e: BackupCrypto.WrongPassphraseException) {
                "Phrase secrète incorrecte"
            } catch (e: Exception) {
                e.message ?: e.javaClass.simpleName
            }
            busy = null
            toast(msg)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(provider.company)
                        Text(provider.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
                actions = {
                    IconButton(onClick = { if (save()) onBack() }) { Icon(Icons.Filled.Save, "Enregistrer") }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Comment obtenir les identifiants", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(provider.help, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(provider.consoleUrl)))
                        } catch (e: Exception) {
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Ouvrir la console ${provider.company}")
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Utiliser cet hébergeur", style = MaterialTheme.typography.titleSmall)
                    Text("Inclus dans chaque sauvegarde", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }

            if (isAzure) {
                OutlinedTextField(
                    value = endpoint, onValueChange = { endpoint = it },
                    label = { Text(provider.secretKeyLabel) },
                    placeholder = { Text(provider.defaultEndpoint) },
                    visualTransformation = if (showSecret) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { SecretToggle(showSecret) { showSecret = !showSecret } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 4,
                )
            } else {
                OutlinedTextField(
                    value = endpoint, onValueChange = { endpoint = it },
                    label = { Text("Point d'accès (endpoint)") }, singleLine = true,
                    supportingText = { Text("Modèle : ${provider.defaultEndpoint}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = region, onValueChange = { region = it },
                    label = { Text("Région") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = bucket, onValueChange = { bucket = it },
                    label = { Text(provider.bucketLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = accessKey, onValueChange = { accessKey = it },
                    label = { Text(provider.accessKeyLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = secretKey, onValueChange = { secretKey = it },
                    label = { Text(provider.secretKeyLabel) }, singleLine = true,
                    visualTransformation = if (showSecret) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { SecretToggle(showSecret) { showSecret = !showSecret } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Adressage virtuel (bucket.hôte)", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Désactivé = adressage par chemin (hôte/bucket)",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = virtualHosted, onCheckedChange = { virtualHosted = it })
                }
            }
            OutlinedTextField(
                value = prefix, onValueChange = { prefix = it },
                label = { Text("Dossier distant") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "🔒 Identifiants chiffrés sur le téléphone (Keystore Android). Les fichiers envoyés sont déjà " +
                    "chiffrés : l'hébergeur ne peut pas lire vos messages.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            busy?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val cfg = current().copy(enabled = true)
                        val err = cfg.validationError()
                        if (err != null) toast(err)
                        else {
                            CloudStore.save(ctx, current())
                            runAction("Test de connexion…") { withContext(Dispatchers.IO) { CloudBackup.testConnection(ctx, providerId) } }
                        }
                    },
                    enabled = busy == null,
                    modifier = Modifier.weight(1f),
                ) { Icon(Icons.Filled.Sync, null); Spacer(Modifier.width(6.dp)); Text("Tester") }
                Button(
                    onClick = { if (save()) onBack() },
                    enabled = busy == null,
                    modifier = Modifier.weight(1f),
                ) { Icon(Icons.Filled.Save, null); Spacer(Modifier.width(6.dp)); Text("Enregistrer") }
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Restaurer depuis ${provider.company}", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(
                onClick = {
                    if (current().validationError() != null) {
                        toast(current().validationError()!!)
                    } else {
                        save(silent = true)
                        runAction("Lecture de la liste des sauvegardes…") {
                            val list = withContext(Dispatchers.IO) { CloudBackup.listBackups(ctx, providerId) }
                            files = list
                            if (list.isEmpty()) "Aucune sauvegarde trouvée dans « ${current().normalizedPrefix} »"
                            else "${list.size} sauvegarde(s) trouvée(s)"
                        }
                    }
                },
                enabled = busy == null,
                modifier = Modifier.fillMaxWidth(),
            ) { Icon(Icons.Filled.History, null); Spacer(Modifier.width(6.dp)); Text("Voir les sauvegardes") }

            files?.forEach { f ->
                ListItem(
                    headlineContent = { Text(f.name) },
                    supportingContent = { Text(Fmt.size(f.size) + if (f.modified.isNotEmpty()) " · ${f.modified}" else "") },
                    leadingContent = { Icon(Icons.Filled.CloudDownload, null) },
                    modifier = Modifier.clickable(enabled = busy == null) { restoreTarget = f },
                )
            }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            TextButton(onClick = { confirmReset = true }) {
                Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(6.dp))
                Text("Effacer cette configuration", color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    restoreTarget?.let { f ->
        RestoreDialog(
            subtitle = "${f.name} · ${Fmt.size(f.size)}",
            onDismiss = { restoreTarget = null },
            onRestore = { pass ->
                restoreTarget = null
                if (!UiState.isDefaultSms) {
                    toast("Sémaphore doit être l'application SMS par défaut pour restaurer")
                } else {
                    runAction("Téléchargement, déchiffrement et restauration…") {
                        val r = withContext(Dispatchers.IO) { CloudBackup.restoreFrom(ctx, providerId, f, pass.toCharArray()) }
                        "Restauration terminée : ${r.inserted} SMS ajoutés, ${r.skipped} déjà présents"
                    }
                }
            },
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Effacer la configuration ?") },
            text = { Text("Les identifiants de ${provider.company} seront supprimés du téléphone. Les sauvegardes déjà envoyées restent chez l'hébergeur.") },
            confirmButton = {
                TextButton(onClick = {
                    CloudStore.remove(ctx, providerId)
                    UiState.refreshTick++
                    confirmReset = false
                    onBack()
                }) { Text("Effacer") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun SecretToggle(visible: Boolean, onToggle: () -> Unit) {
    IconButton(onClick = onToggle) {
        Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (visible) "Masquer" else "Afficher")
    }
}
