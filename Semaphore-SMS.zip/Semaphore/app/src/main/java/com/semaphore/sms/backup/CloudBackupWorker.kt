package com.semaphore.sms.backup

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.Notifications
import java.util.concurrent.TimeUnit

/** Sauvegarde automatique périodique (quotidienne ou hebdomadaire). */
class CloudBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val done = CloudBackup.backupToAll(applicationContext)
        CloudBackup.notifyResult(applicationContext, done)
        if (done.results.any { it.ok }) Result.success() else Result.retry()
    } catch (e: IllegalStateException) {
        Notifications.showBackupResult(applicationContext, "Sauvegarde automatique impossible", e.message ?: "")
        Result.failure()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        private const val NAME = "auto_cloud_backup"

        fun apply(ctx: Context) {
            val prefs = AppPrefs(ctx)
            val wm = WorkManager.getInstance(ctx)
            val mode = prefs.autoBackupMode
            if (mode == 0) {
                wm.cancelUniqueWork(NAME)
                return
            }
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (prefs.backupWifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()
            val req = PeriodicWorkRequestBuilder<CloudBackupWorker>(if (mode == 2) 7L else 1L, TimeUnit.DAYS)
                .setConstraints(constraints)
                .build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
