package com.semaphore.sms.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.semaphore.sms.UiState
import com.semaphore.sms.backup.BackupManager
import com.semaphore.sms.backup.BackupState
import com.semaphore.sms.backup.CloudBackup
import com.semaphore.sms.backup.CloudBackupWorker
import com.semaphore.sms.cloud.CloudProviders
import com.semaphore.sms.cloud.CloudStore
import com.semaphore.sms.crypto.BackupCrypto
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.ui.theme.SecureColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(onBack: () -> Unit, onProvider: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val state by CloudBackup.state.collectAsStateWithLifecycle()

    var hasPass by remember { mutableStateOf(prefs.hasPassphrase()) }
    var showPassDialog by remember { mutableStateOf(false) }
    var autoMode by remember { mutableIntStateOf(prefs.autoBackupMode) }
    var wifiOnly by remember { mutableStateOf(prefs.backupWifiOnly) }
    var retention by remember { mutableIntStateOf(prefs.backupRetention) }
    var localBusy by remember { mutableStateOf<String?>(null) }
    var importData by remember { mutableStateOf<ByteArray?>(null) }
    // Rechargé à chaque retour sur l'écran (après la configuration d'un hébergeur).
    val configs = remember(UiState.refreshTick, state) { CloudStore.all(ctx) }

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val pass = prefs.backupPassphrase()
        if (pass == null) {
            toast("Définissez d'abord une phrase secrète"); return@rememberLauncherForActivityResult
        }
        localBusy = "Chiffrement et export…"
        scope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    val blob = BackupManager(ctx).createEncrypted(pass)
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(blob.data) }
                    "Export chiffré terminé : ${blob.messageCount} SMS (${Fmt.size(blob.data.size.toLong())})"
                } catch (e: Exception) {
                    "Échec de l'export : ${e.message}"
                }
            }
            localBusy = null
            toast(msg)
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val data = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
            }
            if (data == null || !BackupCrypto.isBackup(data)) toast("Ce fichier n'est pas une sauvegarde Sémaphore (.semb)")
            else importData = data
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Sauvegarde chiffrée") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(bottom = 32.dp),
        ) {
            // ---------------- Phrase secrète
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasPass) SecureColors.lockGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.errorContainer
                ),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, null, tint = if (hasPass) SecureColors.lockGreen else MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(10.dp))
                        Text("Chiffrement zero-knowledge", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Vos messages sont chiffrés sur ce téléphone (AES-256-GCM, clé dérivée par PBKDF2 · 310 000 itérations) " +
                            "avant d'être envoyés. Les hébergeurs ne voient que des données illisibles.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (hasPass) "Phrase secrète définie ✓" else "Aucune phrase secrète définie",
                            style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f),
                        )
                        Button(onClick = { showPassDialog = true }) { Text(if (hasPass) "Modifier" else "Définir") }
                    }
                }
            }

            // ---------------- Sauvegarde immédiate
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Sauvegarder maintenant", style = MaterialTheme.typography.titleMedium)
                    val enabledCount = configs.count { it.enabled && it.isComplete }
                    Text(
                        "$enabledCount hébergeur(s) activé(s) sur ${CloudProviders.all.size}" +
                            (if (prefs.lastBackupAt > 0) " · dernière : ${Fmt.full(prefs.lastBackupAt)}" else ""),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    when (val s = state) {
                        is BackupState.Running -> {
                            Text(s.step, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        }
                        is BackupState.Done -> {
                            Text(s.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            s.results.forEach { r ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                    Icon(
                                        if (r.ok) Icons.Filled.CheckCircle else Icons.Filled.Error, null,
                                        tint = if (r.ok) SecureColors.lockGreen else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "${CloudProviders.byId(r.providerId)?.company ?: r.providerId} : ${r.message}",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                        is BackupState.Failed -> Text(s.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                        BackupState.Idle -> {}
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { CloudBackup.runNow(ctx) },
                        enabled = state !is BackupState.Running && hasPass && enabledCount > 0,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.CloudUpload, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Sauvegarder vers les clouds activés")
                    }
                }
            }

            // ---------------- Automatique
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Sauvegarde automatique", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Désactivée", "Quotidienne", "Hebdo.").forEachIndexed { i, label ->
                            FilterChip(
                                selected = autoMode == i,
                                onClick = {
                                    autoMode = i; prefs.autoBackupMode = i
                                    CloudBackupWorker.apply(ctx)
                                },
                                label = { Text(label) },
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Uniquement en Wi-Fi", modifier = Modifier.weight(1f))
                        Switch(checked = wifiOnly, onCheckedChange = {
                            wifiOnly = it; prefs.backupWifiOnly = it
                            CloudBackupWorker.apply(ctx)
                        })
                    }
                    Text("Conserver chez chaque hébergeur", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(3, 10, 30, 0).forEach { n ->
                            FilterChip(
                                selected = retention == n,
                                onClick = { retention = n; prefs.backupRetention = n },
                                label = { Text(if (n == 0) "Tout" else "$n dernières") },
                            )
                        }
                    }
                }
            }

            // ---------------- Fichier local
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Fichier local", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Exporter vers le stockage du téléphone, une clé USB ou n'importe quelle application de fichiers.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    localBusy?.let {
                        Spacer(Modifier.height(8.dp)); Text(it); LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { exportLauncher.launch(BackupManager(ctx).newFileName()) },
                            enabled = hasPass && localBusy == null,
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Filled.FileUpload, null); Spacer(Modifier.width(6.dp)); Text("Exporter")
                        }
                        OutlinedButton(
                            onClick = { importLauncher.launch(arrayOf("*/*")) },
                            enabled = localBusy == null,
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Filled.FileDownload, null); Spacer(Modifier.width(6.dp)); Text("Restaurer")
                        }
                    }
                }
            }

            // ---------------- Hébergeurs
            SectionHeader("Hébergeurs cloud (${CloudProviders.all.size})")
            CloudProviders.all.forEach { p ->
                val cfg = configs.firstOrNull { it.providerId == p.id }
                ProviderRow(
                    flag = p.country,
                    company = p.company,
                    product = p.name,
                    enabled = cfg?.enabled == true && cfg.isComplete,
                    configured = cfg?.isComplete == true,
                    lastOk = cfg?.lastOk,
                    lastStatus = cfg?.lastStatus.orEmpty(),
                    lastAt = cfg?.lastAt ?: 0L,
                    onClick = { onProvider(p.id) },
                )
            }
        }
    }

    if (showPassDialog) {
        PassphraseDialog(
            isChange = hasPass,
            onDismiss = { showPassDialog = false },
            onSave = { pass ->
                prefs.setBackupPassphrase(pass)
                hasPass = true
                showPassDialog = false
                toast("Phrase secrète enregistrée dans le coffre du téléphone")
            },
        )
    }

    importData?.let { data ->
        RestoreDialog(
            onDismiss = { importData = null },
            onRestore = { pass ->
                importData = null
                if (!UiState.isDefaultSms) {
                    toast("Sémaphore doit être l'application SMS par défaut pour restaurer")
                } else {
                localBusy = "Déchiffrement et restauration…"
                scope.launch {
                    val msg = withContext(Dispatchers.IO) {
                        try {
                            val r = BackupManager(ctx).restore(data, pass.toCharArray())
                            "Restauration terminée : ${r.inserted} SMS ajoutés, ${r.skipped} déjà présents"
                        } catch (e: BackupCrypto.WrongPassphraseException) {
                            "Phrase secrète incorrecte"
                        } catch (e: Exception) {
                            "Échec : ${e.message}"
                        }
                    }
                    localBusy = null
                    toast(msg)
                }
                }
            },
        )
    }
}

@Composable
private fun ProviderRow(
    flag: String,
    company: String,
    product: String,
    enabled: Boolean,
    configured: Boolean,
    lastOk: Boolean?,
    lastStatus: String,
    lastAt: Long,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(avatarColor(company).copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(flag, style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(company, style = MaterialTheme.typography.titleSmall)
            Text(product, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (lastAt > 0 && lastStatus.isNotEmpty()) {
                Text(
                    (if (lastOk == true) "✓ " else "✗ ") + lastStatus + " · " + Fmt.short(lastAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (lastOk == true) SecureColors.lockGreen else MaterialTheme.colorScheme.error,
                    maxLines = 1,
                )
            }
        }
        when {
            enabled -> Pill("Activé", SecureColors.lockGreen)
            configured -> Pill("En pause", MaterialTheme.colorScheme.onSurfaceVariant)
            else -> Pill("À configurer", MaterialTheme.colorScheme.primary)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PassphraseDialog(isChange: Boolean, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val error = when {
        p1.isEmpty() -> null
        p1.length < 10 -> "Au moins 10 caractères"
        p2.isNotEmpty() && p1 != p2 -> "Les deux saisies diffèrent"
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.VpnKey, null) },
        title = { Text(if (isChange) "Modifier la phrase secrète" else "Phrase secrète de sauvegarde") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Elle chiffre vos sauvegardes. Notez-la en lieu sûr : sans elle, personne (pas même nous) " +
                        "ne pourra restaurer vos messages.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (isChange) Text(
                    "Les anciennes sauvegardes restent lisibles avec l'ancienne phrase.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = p1, onValueChange = { p1 = it }, label = { Text("Phrase secrète") }, singleLine = true,
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { visible = !visible }) {
                            Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Afficher")
                        }
                    },
                    isError = error != null,
                )
                OutlinedTextField(
                    value = p2, onValueChange = { p2 = it }, label = { Text("Confirmer") }, singleLine = true,
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = error != null,
                    supportingText = { error?.let { Text(it) } },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(p1) }, enabled = p1.length >= 10 && p1 == p2) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@Composable
fun RestoreDialog(onDismiss: () -> Unit, onRestore: (String) -> Unit, subtitle: String? = null) {
    val ctx = LocalContext.current
    val stored = remember { AppPrefs(ctx).backupPassphrase()?.concatToString() ?: "" }
    var pass by remember { mutableStateOf(stored) }
    var visible by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Lock, null) },
        title = { Text("Restaurer la sauvegarde") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                Text(
                    "Les SMS absents du téléphone seront ajoutés ; les doublons sont ignorés.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, label = { Text("Phrase secrète de la sauvegarde") },
                    singleLine = true,
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { visible = !visible }) {
                            Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Afficher")
                        }
                    },
                )
            }
        },
        confirmButton = { TextButton(onClick = { onRestore(pass) }, enabled = pass.isNotEmpty()) { Text("Restaurer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
