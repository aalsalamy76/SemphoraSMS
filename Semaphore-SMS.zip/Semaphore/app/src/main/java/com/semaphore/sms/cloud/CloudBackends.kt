package com.semaphore.sms.cloud

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Configuration d'un hébergeur saisie par l'utilisateur (stockée chiffrée, voir [CloudStore]). */
data class CloudConfig(
    val providerId: String,
    val enabled: Boolean = false,
    val endpoint: String = "",
    val region: String = "",
    val bucket: String = "",
    val accessKey: String = "",
    val secretKey: String = "",
    val prefix: String = "semaphore-backups/",
    val virtualHosted: Boolean = false,
    val lastStatus: String = "",
    val lastOk: Boolean = false,
    val lastAt: Long = 0L,
) {
    val provider: CloudProvider? get() = CloudProviders.byId(providerId)

    /** Préfixe normalisé (« dossier » distant), toujours terminé par « / » s'il n'est pas vide. */
    val normalizedPrefix: String
        get() {
            val p = prefix.trim().trim('/')
            return if (p.isEmpty()) "" else "$p/"
        }

    fun validationError(): String? {
        val kind = provider?.kind ?: return "Hébergeur inconnu"
        if (endpoint.contains('<') || endpoint.contains('>')) return "Remplacez les champs <…> de l'adresse"
        if (!endpoint.startsWith("https://")) return "L'adresse doit commencer par https://"
        return when (kind) {
            CloudKind.AZURE -> if (!endpoint.contains("sig=")) "L'URL SAS doit contenir le jeton (…?sv=…&sig=…)" else null
            CloudKind.S3 -> when {
                bucket.isBlank() -> "Nom du bucket manquant"
                accessKey.isBlank() -> "Clé d'accès manquante"
                secretKey.isBlank() -> "Clé secrète manquante"
                region.isBlank() -> "Région manquante"
                else -> null
            }
        }
    }

    val isComplete: Boolean get() = validationError() == null
}

data class RemoteFile(val key: String, val name: String, val size: Long, val modified: String)

class CloudException(message: String) : Exception(message)

interface CloudBackend {
    fun upload(name: String, data: ByteArray)
    fun list(): List<RemoteFile>
    fun download(key: String): ByteArray
    fun delete(key: String)

    companion object {
        fun create(cfg: CloudConfig): CloudBackend {
            cfg.validationError()?.let { throw CloudException(it) }
            return when (cfg.provider!!.kind) {
                CloudKind.S3 -> S3Backend(cfg)
                CloudKind.AZURE -> AzureBackend(cfg)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------- HTTP

internal class HttpResult(val code: Int, val body: ByteArray) {
    val ok: Boolean get() = code in 200..299
    val text: String get() = String(body, Charsets.UTF_8)
}

internal object Http {
    fun execute(method: String, url: URL, headers: Map<String, String>, body: ByteArray?): HttpResult {
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 20_000
            conn.readTimeout = 120_000
            conn.instanceFollowRedirects = false
            conn.useCaches = false
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream: InputStream? = if (code >= 400) conn.errorStream else conn.inputStream
            val bytes = stream?.use { readAll(it) } ?: ByteArray(0)
            return HttpResult(code, bytes)
        } finally {
            conn.disconnect()
        }
    }

    private fun readAll(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Message d'erreur lisible à partir d'une réponse XML S3/Azure. */
    fun describeError(r: HttpResult): String {
        val t = r.text
        val code = Regex("<Code>(.*?)</Code>").find(t)?.groupValues?.get(1)
        val msg = Regex("<Message>(.*?)</Message>", RegexOption.DOT_MATCHES_ALL).find(t)?.groupValues?.get(1)
            ?.lineSequence()?.firstOrNull()
        val hint = when (r.code) {
            301, 307, 308 -> "mauvaise région ou adresse"
            400 -> "requête refusée"
            401, 403 -> "identifiants refusés ou droits insuffisants"
            404 -> "bucket/conteneur introuvable"
            else -> null
        }
        return listOfNotNull("HTTP ${r.code}", code, msg ?: hint).joinToString(" — ")
    }

    fun xmlUnescape(s: String): String = s
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&#39;", "'").replace("&amp;", "&")
}

// ---------------------------------------------------------------------------------------- S3

/** S3 et compatibles (AWS, Google, Alibaba, Oracle, IBM, Tencent, Huawei, OVHcloud, R2, B2, Wasabi). */
class S3Backend(private val cfg: CloudConfig) : CloudBackend {
    private val base = URL(cfg.endpoint.trim().trimEnd('/'))

    private fun request(method: String, key: String?, query: Map<String, String>, body: ByteArray?): HttpResult {
        val baseHost = base.host
        val host = if (cfg.virtualHosted) "${cfg.bucket}.$baseHost" else baseHost
        val port = base.port
        val hostHeader = if (port == -1 || port == base.defaultPort) host else "$host:$port"
        val basePath = base.path.trimEnd('/')
        val rawPath = when {
            !cfg.virtualHosted && key == null -> "$basePath/${cfg.bucket}"
            !cfg.virtualHosted -> "$basePath/${cfg.bucket}/$key"
            key == null -> "$basePath/"
            else -> "$basePath/$key"
        }
        val canonicalUri = S3Signer.encodePath(rawPath)
        val payloadHash = if (body == null) S3Signer.EMPTY_SHA256 else S3Signer.sha256Hex(body)
        val signed = S3Signer.sign(
            method = method,
            hostHeader = hostHeader,
            canonicalUri = canonicalUri,
            query = query,
            payloadHash = payloadHash,
            region = cfg.region.trim(),
            accessKey = cfg.accessKey.trim(),
            secretKey = cfg.secretKey.trim(),
            amzDate = S3Signer.amzDate(),
        )
        val qs = S3Signer.canonicalQuery(query)
        val portPart = if (port == -1) "" else ":$port"
        val url = URL("${base.protocol}://$host$portPart$canonicalUri" + if (qs.isNotEmpty()) "?$qs" else "")
        val headers = LinkedHashMap<String, String>()
        headers["Authorization"] = signed.authorization
        headers["x-amz-date"] = signed.amzDate
        headers["x-amz-content-sha256"] = signed.payloadHash
        if (body != null) headers["Content-Type"] = "application/octet-stream"
        return Http.execute(method, url, headers, body)
    }

    override fun upload(name: String, data: ByteArray) {
        val r = request("PUT", cfg.normalizedPrefix + name, emptyMap(), data)
        if (!r.ok) throw CloudException(Http.describeError(r))
    }

    override fun list(): List<RemoteFile> {
        val r = request("GET", null, mapOf("list-type" to "2", "prefix" to cfg.normalizedPrefix, "max-keys" to "1000"), null)
        if (!r.ok) throw CloudException(Http.describeError(r))
        val out = ArrayList<RemoteFile>()
        Regex("<Contents>(.*?)</Contents>", RegexOption.DOT_MATCHES_ALL).findAll(r.text).forEach { m ->
            val block = m.groupValues[1]
            val key = Http.xmlUnescape(Regex("<Key>(.*?)</Key>").find(block)?.groupValues?.get(1) ?: return@forEach)
            val size = Regex("<Size>(\\d+)</Size>").find(block)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val modified = Regex("<LastModified>(.*?)</LastModified>").find(block)?.groupValues?.get(1) ?: ""
            out.add(RemoteFile(key, key.removePrefix(cfg.normalizedPrefix), size, modified))
        }
        return out
    }

    override fun download(key: String): ByteArray {
        val r = request("GET", key, emptyMap(), null)
        if (!r.ok) throw CloudException(Http.describeError(r))
        return r.body
    }

    override fun delete(key: String) {
        val r = request("DELETE", key, emptyMap(), null)
        if (!r.ok && r.code != 404) throw CloudException(Http.describeError(r))
    }
}

// ---------------------------------------------------------------------------------------- Azure

/** Azure Blob Storage via une URL SAS de conteneur (aucun secret de compte stocké). */
class AzureBackend(cfg: CloudConfig) : CloudBackend {
    private val containerUrl: String
    private val sas: String
    private val prefix = cfg.normalizedPrefix

    init {
        val raw = cfg.endpoint.trim()
        val i = raw.indexOf('?')
        containerUrl = (if (i < 0) raw else raw.substring(0, i)).trimEnd('/')
        sas = if (i < 0) "" else raw.substring(i + 1)
    }

    private fun blobUrl(key: String) = URL("$containerUrl/${S3Signer.encodePath(key)}?$sas")

    private val baseHeaders = mapOf("x-ms-version" to "2021-08-06")

    override fun upload(name: String, data: ByteArray) {
        val r = Http.execute(
            "PUT", blobUrl(prefix + name),
            baseHeaders + mapOf("x-ms-blob-type" to "BlockBlob", "Content-Type" to "application/octet-stream"),
            data
        )
        if (!r.ok) throw CloudException(Http.describeError(r))
    }

    override fun list(): List<RemoteFile> {
        val url = URL("$containerUrl?restype=container&comp=list&prefix=${S3Signer.uriEncode(prefix)}&$sas")
        val r = Http.execute("GET", url, baseHeaders, null)
        if (!r.ok) throw CloudException(Http.describeError(r))
        val out = ArrayList<RemoteFile>()
        Regex("<Blob>(.*?)</Blob>", RegexOption.DOT_MATCHES_ALL).findAll(r.text).forEach { m ->
            val block = m.groupValues[1]
            val key = Http.xmlUnescape(Regex("<Name>(.*?)</Name>").find(block)?.groupValues?.get(1) ?: return@forEach)
            val size = Regex("<Content-Length>(\\d+)</Content-Length>").find(block)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val modified = Regex("<Last-Modified>(.*?)</Last-Modified>").find(block)?.groupValues?.get(1) ?: ""
            out.add(RemoteFile(key, key.removePrefix(prefix), size, modified))
        }
        return out
    }

    override fun download(key: String): ByteArray {
        val r = Http.execute("GET", blobUrl(key), baseHeaders, null)
        if (!r.ok) throw CloudException(Http.describeError(r))
        return r.body
    }

    override fun delete(key: String) {
        val r = Http.execute("DELETE", blobUrl(key), baseHeaders, null)
        if (!r.ok && r.code != 404) throw CloudException(Http.describeError(r))
    }
}
