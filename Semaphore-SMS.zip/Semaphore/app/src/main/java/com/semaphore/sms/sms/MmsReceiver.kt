package com.semaphore.sms.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Notification de MMS entrant (WAP Push). Requis par Android pour le rôle « SMS par défaut ».
 * Le téléchargement complet des MMS n'est pas implémenté dans cette version :
 * l'utilisateur est averti qu'un MMS est en attente.
 */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.WAP_PUSH_DELIVER") return
        Notifications.showMmsPending(context)
    }
}
