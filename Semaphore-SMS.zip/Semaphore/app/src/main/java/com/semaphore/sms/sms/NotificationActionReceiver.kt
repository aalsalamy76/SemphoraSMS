package com.semaphore.sms.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import com.semaphore.sms.MainActivity
import com.semaphore.sms.data.SmsRepository

/** Actions des notifications : réponse rapide et « marquer comme lu ». */
class NotificationActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_REPLY = "com.semaphore.sms.action.REPLY"
        const val ACTION_MARK_READ = "com.semaphore.sms.action.MARK_READ"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val threadId = intent.getLongExtra(MainActivity.EXTRA_THREAD_ID, 0L)
        val address = intent.getStringExtra(MainActivity.EXTRA_ADDRESS) ?: return
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                val repo = SmsRepository(app)
                when (intent.action) {
                    ACTION_REPLY -> {
                        val text = RemoteInput.getResultsFromIntent(intent)
                            ?.getCharSequence(Notifications.KEY_REPLY)?.toString()
                        if (!text.isNullOrBlank()) SmsSender.send(app, address, text)
                        repo.markThreadRead(threadId)
                        Notifications.cancel(app, threadId)
                    }
                    ACTION_MARK_READ -> {
                        repo.markThreadRead(threadId)
                        Notifications.cancel(app, threadId)
                    }
                }
            } finally {
                pending.finish()
            }
        }.start()
    }
}
