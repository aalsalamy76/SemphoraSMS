package com.semaphore.sms.crypto

import java.nio.ByteBuffer
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Protocole de chiffrement de bout en bout des SMS entre deux téléphones équipés de Sémaphore.
 *
 *  - Identité : paire de clés ECDH P-256 générée sur l'appareil (la clé privée ne quitte jamais le téléphone).
 *  - Échange : chaque appareil envoie sa clé publique dans un SMS « #SEMK1:… ».
 *  - Clé de session : ECDH → HKDF-SHA256 (sel = SHA-256 des deux clés publiques triées) → AES-256.
 *  - Messages : AES-256-GCM, IV aléatoire de 96 bits, authentifiés (toute altération est détectée).
 *  - Vérification : « numéro de sécurité » de 30 chiffres à comparer de vive voix, comme sur Signal.
 *
 * Cette partie n'utilise que l'API Java standard, ce qui permet de la tester hors Android.
 */
object E2ECore {
    const val KEY_PREFIX = "#SEMK1:"
    const val MSG_PREFIX = "#SEM1:"
    private val INFO = "Semaphore-E2E-v1".toByteArray(Charsets.US_ASCII)
    private val AAD = "SEM1".toByteArray(Charsets.US_ASCII)
    private const val IV_LEN = 12
    private val random = SecureRandom()
    private val b64e = Base64.getEncoder()
    private val b64d = Base64.getDecoder()

    fun isKeyMessage(body: String?): Boolean = body?.startsWith(KEY_PREFIX) == true
    fun isEncrypted(body: String?): Boolean = body?.startsWith(MSG_PREFIX) == true

    fun generateKeyPair(): KeyPair {
        val gen = KeyPairGenerator.getInstance("EC")
        gen.initialize(ECGenParameterSpec("secp256r1"), random)
        return gen.generateKeyPair()
    }

    fun decodePublic(encoded: ByteArray): PublicKey =
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(encoded))

    fun decodePrivate(encoded: ByteArray): PrivateKey =
        KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(encoded))

    fun b64(bytes: ByteArray): String = b64e.encodeToString(bytes)
    fun unb64(s: String): ByteArray = b64d.decode(s)

    fun keyMessage(publicKey: ByteArray): String = KEY_PREFIX + b64(publicKey)

    /** Extrait et valide la clé publique d'un SMS d'échange de clés. */
    fun parseKeyMessage(body: String): ByteArray? = try {
        val bytes = unb64(body.removePrefix(KEY_PREFIX).trim())
        decodePublic(bytes) // valide le point de la courbe
        bytes
    } catch (e: Exception) {
        null
    }

    /** Clé AES-256 partagée entre `myPrivate` et `peerPublic`. Symétrique : A→B et B→A donnent la même clé. */
    fun deriveKey(myPrivate: PrivateKey, myPublic: ByteArray, peerPublic: ByteArray): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(myPrivate)
        ka.doPhase(decodePublic(peerPublic), true)
        val secret = ka.generateSecret()
        val salt = sha256(sortedConcat(myPublic, peerPublic))
        return hkdf(secret, salt, INFO, 32)
    }

    fun encrypt(key: ByteArray, plain: String): String {
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD)
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return MSG_PREFIX + b64(iv + ct)
    }

    /** Renvoie le texte clair, ou null si la clé ne correspond pas / le message a été altéré. */
    fun decrypt(key: ByteArray, body: String): String? = try {
        val all = unb64(body.removePrefix(MSG_PREFIX).trim())
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, all, 0, IV_LEN))
        cipher.updateAAD(AAD)
        String(cipher.doFinal(all, IV_LEN, all.size - IV_LEN), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    /** Taille (en caractères) du SMS chiffré produit pour un texte donné. */
    fun encryptedLength(plain: String): Int {
        val n = IV_LEN + plain.toByteArray(Charsets.UTF_8).size + 16
        return MSG_PREFIX.length + 4 * ((n + 2) / 3)
    }

    /** Numéro de sécurité commun aux deux appareils (identique des deux côtés). */
    fun safetyNumber(a: ByteArray, b: ByteArray): String {
        var h = sortedConcat(a, b)
        repeat(1024) { h = sha256(h) }
        val sb = StringBuilder()
        var i = 0
        while (sb.length < 30) {
            val chunk = ByteBuffer.wrap(h, i, 4).int.toLong() and 0xFFFFFFFFL
            sb.append((chunk % 100000).toString().padStart(5, '0'))
            i += 4
        }
        return sb.toString().chunked(5).joinToString(" ")
    }

    /** Empreinte courte d'une clé publique (affichage). */
    fun fingerprint(pub: ByteArray): String =
        sha256(pub).take(10).joinToString(":") { "%02X".format(it) }

    // ---------- primitives ----------
    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

    fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    /** HKDF (RFC 5869) avec HMAC-SHA256. */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        val prk = hmac(if (salt.isEmpty()) ByteArray(32) else salt, ikm)
        val out = ByteArray(length)
        var previous = ByteArray(0)
        var offset = 0
        var counter = 1
        while (offset < length) {
            previous = hmac(prk, previous + info + byteArrayOf(counter.toByte()))
            val n = minOf(previous.size, length - offset)
            System.arraycopy(previous, 0, out, offset, n)
            offset += n
            counter++
        }
        return out
    }

    private fun sortedConcat(a: ByteArray, b: ByteArray): ByteArray =
        if (compare(a, b) <= 0) a + b else b + a

    private fun compare(a: ByteArray, b: ByteArray): Int {
        for (i in 0 until minOf(a.size, b.size)) {
            val x = a[i].toInt() and 0xFF
            val y = b[i].toInt() and 0xFF
            if (x != y) return x - y
        }
        return a.size - b.size
    }
}
