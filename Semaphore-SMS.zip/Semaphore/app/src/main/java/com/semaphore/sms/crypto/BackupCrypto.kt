package com.semaphore.sms.crypto

import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Chiffrement des sauvegardes, effectué sur le téléphone AVANT tout envoi :
 * les hébergeurs cloud ne reçoivent que des données illisibles (« zero-knowledge »).
 *
 * Format du fichier .semb :
 *   "SEMB" | version (1 octet) | itérations PBKDF2 (4 octets) | sel (16) | IV (12) | données AES-256-GCM
 * L'en-tête complet est authentifié (AAD) : toute modification est détectée.
 */
object BackupCrypto {
    private val MAGIC = "SEMB".toByteArray(Charsets.US_ASCII)
    private const val VERSION: Byte = 1
    const val ITERATIONS = 310_000
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val HEADER_LEN = 4 + 1 + 4 + SALT_LEN + IV_LEN
    private val random = SecureRandom()

    class WrongPassphraseException : Exception("Phrase secrète incorrecte ou fichier altéré")
    class InvalidFormatException : Exception("Ce fichier n'est pas une sauvegarde Sémaphore")

    fun encrypt(plain: ByteArray, passphrase: CharArray, iterations: Int = ITERATIONS): ByteArray {
        val salt = ByteArray(SALT_LEN).also { random.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val header = ByteBuffer.allocate(HEADER_LEN)
            .put(MAGIC).put(VERSION).putInt(iterations).put(salt).put(iv)
            .array()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, derive(passphrase, salt, iterations), GCMParameterSpec(128, iv))
        cipher.updateAAD(header)
        return header + cipher.doFinal(plain)
    }

    fun decrypt(data: ByteArray, passphrase: CharArray): ByteArray {
        if (data.size < HEADER_LEN + 16) throw InvalidFormatException()
        val buf = ByteBuffer.wrap(data)
        val magic = ByteArray(4).also { buf.get(it) }
        if (!magic.contentEquals(MAGIC)) throw InvalidFormatException()
        val version = buf.get()
        if (version != VERSION) throw InvalidFormatException()
        val iterations = buf.int
        if (iterations < 1000 || iterations > 10_000_000) throw InvalidFormatException()
        val salt = ByteArray(SALT_LEN).also { buf.get(it) }
        val iv = ByteArray(IV_LEN).also { buf.get(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, derive(passphrase, salt, iterations), GCMParameterSpec(128, iv))
        cipher.updateAAD(data, 0, HEADER_LEN)
        return try {
            cipher.doFinal(data, HEADER_LEN, data.size - HEADER_LEN)
        } catch (e: javax.crypto.AEADBadTagException) {
            throw WrongPassphraseException()
        }
    }

    fun isBackup(data: ByteArray): Boolean =
        data.size > 4 && data.copyOfRange(0, 4).contentEquals(MAGIC)

    private fun derive(pass: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(pass, salt, iterations, 256)
        try {
            return SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}
