package com.semaphore.sms.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsMessage
import com.semaphore.sms.data.Sms
import com.semaphore.sms.data.SmsRepository

/** Met à jour l'état des SMS envoyés (envoyé / échec / distribué). */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.data ?: return
        if (uri.scheme != "content") return
        val repo = SmsRepository(context)
        when (intent.action) {
            SmsSender.ACTION_SENT -> {
                if (resultCode == Activity.RESULT_OK) {
                    repo.setType(uri, Sms.TYPE_SENT)
                } else {
                    repo.setType(uri, Sms.TYPE_FAILED)
                    Notifications.showSendFailed(context, uri)
                }
            }
            SmsSender.ACTION_DELIVERED -> {
                var status = Sms.STATUS_COMPLETE
                try {
                    val pdu = intent.getByteArrayExtra("pdu")
                    val format = intent.getStringExtra("format")
                    if (pdu != null) {
                        val msg = SmsMessage.createFromPdu(pdu, format)
                        val st = msg?.status ?: 0
                        status = when {
                            st == 0 -> Sms.STATUS_COMPLETE
                            st >= 64 -> Sms.STATUS_FAILED
                            st >= 32 -> Sms.STATUS_PENDING
                            else -> Sms.STATUS_COMPLETE
                        }
                    }
                } catch (e: Exception) {
                }
                repo.setStatus(uri, status)
            }
        }
    }
}
