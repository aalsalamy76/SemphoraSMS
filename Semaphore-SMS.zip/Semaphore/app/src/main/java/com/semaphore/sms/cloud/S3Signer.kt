package com.semaphore.sms.cloud

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Signature AWS Signature Version 4 pour S3 et les services compatibles. Code Java pur, testable. */
object S3Signer {
    const val EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

    data class Signed(val authorization: String, val amzDate: String, val payloadHash: String)

    fun amzDate(now: Date = Date()): String =
        SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(now)

    /**
     * @param hostHeader valeur exacte de l'en-tête Host (avec le port s'il n'est pas standard)
     * @param canonicalUri chemin déjà encodé (ex. "/bucket/dossier/fichier.semb")
     * @param query paramètres bruts (non encodés)
     */
    fun sign(
        method: String,
        hostHeader: String,
        canonicalUri: String,
        query: Map<String, String>,
        payloadHash: String,
        region: String,
        accessKey: String,
        secretKey: String,
        amzDate: String,
        service: String = "s3",
    ): Signed {
        val dateStamp = amzDate.substring(0, 8)
        val canonicalQuery = canonicalQuery(query)
        val canonicalHeaders = "host:$hostHeader\nx-amz-content-sha256:$payloadHash\nx-amz-date:$amzDate\n"
        val signedHeaders = "host;x-amz-content-sha256;x-amz-date"
        val canonicalRequest = listOf(
            method, canonicalUri, canonicalQuery, canonicalHeaders, signedHeaders, payloadHash
        ).joinToString("\n")
        val scope = "$dateStamp/$region/$service/aws4_request"
        val stringToSign = "AWS4-HMAC-SHA256\n$amzDate\n$scope\n${hex(sha256(canonicalRequest.toByteArray(Charsets.UTF_8)))}"
        var k = hmac(("AWS4$secretKey").toByteArray(Charsets.UTF_8), dateStamp)
        k = hmac(k, region)
        k = hmac(k, service)
        k = hmac(k, "aws4_request")
        val signature = hex(hmac(k, stringToSign))
        val auth = "AWS4-HMAC-SHA256 Credential=$accessKey/$scope, SignedHeaders=$signedHeaders, Signature=$signature"
        return Signed(auth, amzDate, payloadHash)
    }

    fun canonicalQuery(query: Map<String, String>): String =
        query.entries
            .map { uriEncode(it.key) to uriEncode(it.value) }
            .sortedWith(compareBy({ it.first }, { it.second }))
            .joinToString("&") { "${it.first}=${it.second}" }

    /** Encodage RFC 3986 exigé par SigV4 (les caractères non réservés restent tels quels). */
    fun uriEncode(value: String, keepSlash: Boolean = false): String {
        val sb = StringBuilder()
        for (b in value.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xFF
            val ch = c.toChar()
            if ((ch in 'A'..'Z') || (ch in 'a'..'z') || (ch in '0'..'9') || ch == '-' || ch == '_' || ch == '.' || ch == '~' ||
                (keepSlash && ch == '/')
            ) {
                sb.append(ch)
            } else {
                sb.append('%').append("0123456789ABCDEF"[c shr 4]).append("0123456789ABCDEF"[c and 0x0F])
            }
        }
        return sb.toString()
    }

    fun encodePath(path: String): String = uriEncode(path, keepSlash = true)

    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

    fun sha256Hex(data: ByteArray): String = hex(sha256(data))

    fun hmac(key: ByteArray, data: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8))
    }

    fun hex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append("0123456789abcdef"[v shr 4]).append("0123456789abcdef"[v and 0x0F])
        }
        return sb.toString()
    }
}
