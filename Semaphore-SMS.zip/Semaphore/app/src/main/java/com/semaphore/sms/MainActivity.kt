package com.semaphore.sms

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Telephony
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.HeadlessSmsSendService
import com.semaphore.sms.ui.AppNav
import com.semaphore.sms.ui.NavRequest
import com.semaphore.sms.ui.theme.SecureColors
import com.semaphore.sms.ui.theme.SemaphoreTheme

class MainActivity : FragmentActivity() {

    companion object {
        const val EXTRA_THREAD_ID = "com.semaphore.sms.THREAD_ID"
        const val EXTRA_ADDRESS = "com.semaphore.sms.ADDRESS"
        const val EXTRA_OPEN = "com.semaphore.sms.OPEN"
        private const val RELOCK_AFTER_MS = 30_000L
    }

    private var pendingNav by mutableStateOf<NavRequest?>(null)
    private var locked by mutableStateOf(false)
    private var backgroundedAt = 0L
    private var authInProgress = false

    private val permissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { UiState.refresh(this) }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            UiState.refresh(this)
            askPermissions()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        UiState.init(this)
        locked = AppPrefs(this).appLock
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            SemaphoreTheme(UiState.themeMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (locked) {
                        LockScreen(onUnlock = { authenticate() })
                    } else {
                        AppNav(
                            pending = pendingNav,
                            onPendingConsumed = { pendingNav = null },
                            onRequestDefault = { requestDefaultSms() },
                        )
                    }
                }
            }
        }

        // Une seule demande à la fois : le rôle SMS d'abord (il accorde les permissions SMS),
        // puis les permissions restantes (contacts, notifications) au retour.
        if (!UiState.isDefaultSms && savedInstanceState == null) requestDefaultSms() else askPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        if (AppPrefs(this).appLock && backgroundedAt > 0 &&
            SystemClock.elapsedRealtime() - backgroundedAt > RELOCK_AFTER_MS
        ) {
            locked = true
        }
        if (locked) authenticate()
    }

    override fun onResume() {
        super.onResume()
        UiState.refresh(this)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) backgroundedAt = SystemClock.elapsedRealtime()
    }

    // ------------------------------------------------------------------ Intents

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val threadId = intent.getLongExtra(EXTRA_THREAD_ID, -1L)
        if (threadId > 0) {
            pendingNav = NavRequest.Thread(threadId, intent.getStringExtra(EXTRA_ADDRESS) ?: "")
            return
        }
        if (intent.getStringExtra(EXTRA_OPEN) == "backup") {
            pendingNav = NavRequest.Backup
            return
        }
        val action = intent.action
        val data = intent.data
        val scheme = data?.scheme
        if ((action == Intent.ACTION_SENDTO || action == Intent.ACTION_SEND || action == Intent.ACTION_VIEW) &&
            scheme in setOf("sms", "smsto", "mms", "mmsto")
        ) {
            val to = HeadlessSmsSendService.recipientsFromUri(data).joinToString(",")
            val body = intent.getStringExtra("sms_body")
                ?: intent.getStringExtra(Intent.EXTRA_TEXT)
                ?: data?.getQueryParameterSafe("body")
                ?: ""
            pendingNav = NavRequest.Compose(to, body)
            return
        }
        if (action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            pendingNav = NavRequest.Compose("", text)
        }
    }

    private fun android.net.Uri.getQueryParameterSafe(name: String): String? = try {
        // Les URI sms: sont opaques : on lit « ?body= » à la main.
        val q = schemeSpecificPart.substringAfter('?', "")
        q.split('&').firstOrNull { it.startsWith("$name=") }?.substringAfter('=')?.let { android.net.Uri.decode(it) }
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------------ Application SMS par défaut

    fun requestDefaultSms() {
        var launched = false
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
                    launched = true
                }
            } else {
                @Suppress("DEPRECATION")
                val i = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                roleLauncher.launch(i)
                launched = true
            }
        } catch (e: Exception) {
        }
        if (!launched) askPermissions()
    }

    private fun askPermissions() {
        val wanted = buildList {
            add(Manifest.permission.READ_SMS)
            add(Manifest.permission.SEND_SMS)
            add(Manifest.permission.RECEIVE_SMS)
            add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionsLauncher.launch(wanted.toTypedArray())
    }

    // ------------------------------------------------------------------ Verrouillage

    private fun authenticate() {
        if (authInProgress) return
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            // Plus aucun verrouillage d'écran configuré : on ne bloque pas l'utilisateur hors de ses messages.
            locked = false
            return
        }
        authInProgress = true
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                authInProgress = false
                locked = false
                backgroundedAt = 0L
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                authInProgress = false
            }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Déverrouiller Sémaphore")
                .setSubtitle("Vos messages sont protégés")
                .setAllowedAuthenticators(authenticators)
                .build()
        )
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Filled.Fingerprint, null, tint = SecureColors.lockGreen, modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(16.dp))
            Text("Sémaphore est verrouillé", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text("Authentifiez-vous pour accéder à vos messages.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onUnlock) { Text("Déverrouiller") }
        }
    }
}
