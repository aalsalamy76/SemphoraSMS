package com.semaphore.sms.sms

import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.IBinder

/** « Répondre par SMS » depuis l'écran d'appel entrant. */
class HeadlessSmsSendService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "android.intent.action.RESPOND_VIA_MESSAGE") {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            val recipients = recipientsFromUri(intent.data)
            if (!text.isNullOrBlank() && recipients.isNotEmpty()) {
                Thread {
                    recipients.forEach { SmsSender.send(this, it, text) }
                    stopSelf(startId)
                }.start()
                return START_NOT_STICKY
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }

    companion object {
        fun recipientsFromUri(uri: Uri?): List<String> {
            val ssp = uri?.schemeSpecificPart ?: return emptyList()
            return ssp.substringBefore('?')
                .removePrefix("//")
                .split(',', ';')
                .map { Uri.decode(it).trim() }
                .filter { it.isNotEmpty() }
        }
    }
}
