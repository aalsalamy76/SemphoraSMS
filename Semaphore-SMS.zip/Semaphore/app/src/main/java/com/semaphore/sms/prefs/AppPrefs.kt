package com.semaphore.sms.prefs

import android.content.Context
import android.content.SharedPreferences
import com.semaphore.sms.crypto.KeyVault
import org.json.JSONArray
import org.json.JSONObject

data class ScheduledMessage(
    val id: String,
    val address: String,
    val body: String,
    val at: Long,
)

/** Préférences de l'application. Les valeurs sensibles passent par [KeyVault]. */
class AppPrefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("semaphore", Context.MODE_PRIVATE)

    // ---------- Apparence ----------
    /** 0 = système, 1 = clair, 2 = sombre */
    var themeMode: Int
        get() = sp.getInt("theme_mode", 0)
        set(v) = sp.edit().putInt("theme_mode", v).apply()

    // ---------- Sécurité ----------
    var appLock: Boolean
        get() = sp.getBoolean("app_lock", false)
        set(v) = sp.edit().putBoolean("app_lock", v).apply()

    var hidePreviews: Boolean
        get() = sp.getBoolean("hide_previews", false)
        set(v) = sp.edit().putBoolean("hide_previews", v).apply()

    // ---------- Sauvegarde ----------
    /** 0 = désactivée, 1 = quotidienne, 2 = hebdomadaire */
    var autoBackupMode: Int
        get() = sp.getInt("auto_backup", 0)
        set(v) = sp.edit().putInt("auto_backup", v).apply()

    var backupWifiOnly: Boolean
        get() = sp.getBoolean("backup_wifi_only", true)
        set(v) = sp.edit().putBoolean("backup_wifi_only", v).apply()

    var backupRetention: Int
        get() = sp.getInt("backup_retention", 10)
        set(v) = sp.edit().putInt("backup_retention", v).apply()

    var lastBackupAt: Long
        get() = sp.getLong("last_backup_at", 0L)
        set(v) = sp.edit().putLong("last_backup_at", v).apply()

    var lastBackupSummary: String
        get() = sp.getString("last_backup_summary", "") ?: ""
        set(v) = sp.edit().putString("last_backup_summary", v).apply()

    fun hasPassphrase(): Boolean = sp.contains("backup_pass")

    fun backupPassphrase(): CharArray? =
        sp.getString("backup_pass", null)?.let { KeyVault.decryptString(it) }?.toCharArray()

    fun setBackupPassphrase(pass: String?) {
        if (pass == null) sp.edit().remove("backup_pass").apply()
        else sp.edit().putString("backup_pass", KeyVault.encryptString(pass)).apply()
    }

    // ---------- Secrets génériques ----------
    fun getSecret(name: String): String? =
        sp.getString("secret_$name", null)?.let { KeyVault.decryptString(it) }

    fun putSecret(name: String, value: String?) {
        if (value == null) sp.edit().remove("secret_$name").apply()
        else sp.edit().putString("secret_$name", KeyVault.encryptString(value)).apply()
    }

    fun getRaw(name: String): String? = sp.getString(name, null)
    fun putRaw(name: String, value: String?) {
        if (value == null) sp.edit().remove(name).apply() else sp.edit().putString(name, value).apply()
    }

    // ---------- Chiffrement de bout en bout ----------
    fun peerKey(numberKey: String): String? = sp.getString("peer_$numberKey", null)

    fun setPeerKey(numberKey: String, key: String?) {
        if (key == null) sp.edit().remove("peer_$numberKey").apply()
        else sp.edit().putString("peer_$numberKey", key).apply()
    }

    /** Anciennes clés du contact, pour relire les anciens messages après un changement de clé. */
    fun peerKeyHistory(numberKey: String): List<String> {
        val raw = sp.getString("peerhist_$numberKey", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addPeerKeyHistory(numberKey: String, key: String) {
        val list = peerKeyHistory(numberKey).toMutableList()
        if (key !in list) list.add(0, key)
        val arr = JSONArray()
        list.take(5).forEach { arr.put(it) }
        sp.edit().putString("peerhist_$numberKey", arr.toString()).apply()
    }

    /** Toutes les clés publiques connues des contacts (clé d'annuaire → clé). */
    fun allPeerKeys(): Map<String, String> =
        sp.all.entries
            .filter { it.key.startsWith("peer_") && it.value is String }
            .associate { it.key.removePrefix("peer_") to (it.value as String) }

    fun keyChanged(numberKey: String): Boolean = sp.getBoolean("keychg_$numberKey", false)
    fun setKeyChanged(numberKey: String, v: Boolean) =
        sp.edit().putBoolean("keychg_$numberKey", v).apply()

    fun keyVerified(numberKey: String): Boolean = sp.getBoolean("keyok_$numberKey", false)
    fun setKeyVerified(numberKey: String, v: Boolean) =
        sp.edit().putBoolean("keyok_$numberKey", v).apply()

    /** Chiffrement activé pour ce contact (vrai par défaut dès que sa clé est connue). */
    fun e2eEnabled(numberKey: String): Boolean = sp.getBoolean("e2e_$numberKey", true)
    fun setE2eEnabled(numberKey: String, v: Boolean) =
        sp.edit().putBoolean("e2e_$numberKey", v).apply()

    fun keySent(numberKey: String): Boolean = sp.getBoolean("keysent_$numberKey", false)
    fun setKeySent(numberKey: String, v: Boolean) =
        sp.edit().putBoolean("keysent_$numberKey", v).apply()

    fun resetAllKeySent() {
        val ed = sp.edit()
        sp.all.keys.filter { it.startsWith("keysent_") }.forEach { ed.remove(it) }
        ed.apply()
    }

    // ---------- Messages programmés ----------
    fun scheduled(): List<ScheduledMessage> {
        val enc = sp.getString("scheduled", null) ?: return emptyList()
        val raw = KeyVault.decryptString(enc) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) {
                val o = arr.getJSONObject(it)
                ScheduledMessage(
                    id = o.getString("id"),
                    address = o.getString("address"),
                    body = o.getString("body"),
                    at = o.getLong("at"),
                )
            }.sortedBy { it.at }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addScheduled(m: ScheduledMessage) = saveScheduled(scheduled() + m)

    @Synchronized
    fun removeScheduled(id: String) = saveScheduled(scheduled().filter { it.id != id })

    private fun saveScheduled(list: List<ScheduledMessage>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("address", it.address)
                    .put("body", it.body)
                    .put("at", it.at)
            )
        }
        // Le contenu des messages programmés est chiffré au repos.
        sp.edit().putString("scheduled", KeyVault.encryptString(arr.toString())).apply()
    }
}
