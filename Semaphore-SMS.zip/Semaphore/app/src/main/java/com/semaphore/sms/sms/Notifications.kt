package com.semaphore.sms.sms

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import com.semaphore.sms.MainActivity
import com.semaphore.sms.R
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.data.Contacts
import com.semaphore.sms.data.SmsRepository
import com.semaphore.sms.prefs.AppPrefs

object Notifications {
    const val CH_MESSAGES = "messages"
    const val CH_SYSTEM = "system"
    const val KEY_REPLY = "reply_text"
    private const val ID_MMS = 900_001
    private const val ID_BACKUP = 900_002

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, "Messages", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Nouveaux SMS reçus"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SYSTEM, "Sauvegardes et état", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Sauvegardes cloud, échecs d'envoi"
            }
        )
    }

    private fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openThreadIntent(ctx: Context, threadId: Long, address: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_THREAD_ID, threadId)
            .putExtra(MainActivity.EXTRA_ADDRESS, address)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            ctx, threadId.toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    @SuppressLint("MissingPermission")
    fun showIncoming(ctx: Context, address: String, threadId: Long) {
        if (!canNotify(ctx)) return
        val prefs = AppPrefs(ctx)
        val name = Contacts.name(ctx, address)
        val unread = SmsRepository(ctx).unreadInThread(threadId)
        if (unread.isEmpty()) return
        val hide = prefs.hidePreviews || prefs.appLock
        val encrypted = E2E.isActive(ctx, address)

        val me = Person.Builder().setName("Moi").build()
        val sender = Person.Builder().setName(name).setKey(address).build()
        val style = NotificationCompat.MessagingStyle(me)
        unread.forEach { (text, date) ->
            style.addMessage(if (hide) "Nouveau message" else text, date, sender)
        }

        val replyPi = actionIntent(ctx, NotificationActionReceiver.ACTION_REPLY, threadId, address, mutable = true)
        val remoteInput = RemoteInput.Builder(KEY_REPLY)
            .setLabel(if (encrypted) "Réponse chiffrée…" else "Répondre…")
            .build()
        val replyAction = NotificationCompat.Action.Builder(android.R.drawable.ic_menu_send, "Répondre", replyPi)
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(true)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .build()
        val readAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_view, "Marquer comme lu",
            actionIntent(ctx, NotificationActionReceiver.ACTION_MARK_READ, threadId, address, mutable = false)
        ).setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ).build()

        val n = NotificationCompat.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_message)
            .setStyle(style)
            .setContentTitle(name)
            .setContentText(if (hide) "Nouveau message" else unread.last().first)
            .setSubText(if (encrypted) "🔒 Chiffré de bout en bout" else null)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(if (hide) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_PUBLIC)
            .setNumber(unread.size)
            .setAutoCancel(true)
            .setContentIntent(openThreadIntent(ctx, threadId, address))
            .addAction(replyAction)
            .addAction(readAction)
            .build()
        NotificationManagerCompat.from(ctx).notify(threadId.toInt(), n)
    }

    private fun actionIntent(ctx: Context, action: String, threadId: Long, address: String, mutable: Boolean): PendingIntent {
        val i = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(action)
            .setData(Uri.parse("semaphore://thread/$threadId"))
            .putExtra(MainActivity.EXTRA_THREAD_ID, threadId)
            .putExtra(MainActivity.EXTRA_ADDRESS, address)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or when {
            mutable && Build.VERSION.SDK_INT >= 31 -> PendingIntent.FLAG_MUTABLE
            mutable -> 0
            else -> PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(ctx, threadId.toInt(), i, flags)
    }

    fun cancel(ctx: Context, threadId: Long) {
        NotificationManagerCompat.from(ctx).cancel(threadId.toInt())
    }

    @SuppressLint("MissingPermission")
    fun showSendFailed(ctx: Context, messageUri: Uri) {
        if (!canNotify(ctx)) return
        var address = ""
        var threadId = 0L
        try {
            ctx.contentResolver.query(messageUri, arrayOf("address", "thread_id"), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    address = c.getString(0) ?: ""
                    threadId = c.getLong(1)
                }
            }
        } catch (e: Exception) {
        }
        val n = NotificationCompat.Builder(ctx, CH_SYSTEM)
            .setSmallIcon(R.drawable.ic_stat_message)
            .setContentTitle("Échec de l'envoi")
            .setContentText("Le message à ${Contacts.name(ctx, address)} n'a pas pu être envoyé. Touchez pour réessayer.")
            .setAutoCancel(true)
            .apply { if (threadId > 0) setContentIntent(openThreadIntent(ctx, threadId, address)) }
            .build()
        NotificationManagerCompat.from(ctx).notify((threadId + 500_000).toInt(), n)
    }

    @SuppressLint("MissingPermission")
    fun showMmsPending(ctx: Context) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_message)
            .setContentTitle("MMS reçu")
            .setContentText("Un MMS (photo/vidéo) est en attente. Sémaphore ne télécharge pas encore les MMS.")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Un MMS (photo, vidéo ou message de groupe) est en attente. Sémaphore ne télécharge pas encore " +
                        "les MMS : rebasculez temporairement sur l'application Messages d'origine pour le récupérer."
                )
            )
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(ID_MMS, n)
    }

    @SuppressLint("MissingPermission")
    fun showInfo(ctx: Context, title: String, text: String) {
        if (!canNotify(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH_SYSTEM)
            .setSmallIcon(R.drawable.ic_stat_message)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify((System.currentTimeMillis() % 100_000).toInt() + 700_000, n)
    }

    @SuppressLint("MissingPermission")
    fun showBackupResult(ctx: Context, title: String, text: String) {
        if (!canNotify(ctx)) return
        val i = Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN, "backup")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, ID_BACKUP, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH_SYSTEM)
            .setSmallIcon(R.drawable.ic_stat_message)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(ID_BACKUP, n)
    }
}
