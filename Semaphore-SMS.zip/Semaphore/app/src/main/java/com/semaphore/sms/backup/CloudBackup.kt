package com.semaphore.sms.backup

import android.content.Context
import com.semaphore.sms.cloud.CloudBackend
import com.semaphore.sms.cloud.CloudStore
import com.semaphore.sms.cloud.RemoteFile
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ProviderResult(val providerId: String, val ok: Boolean, val message: String)

sealed class BackupState {
    data object Idle : BackupState()
    data class Running(val step: String) : BackupState()
    data class Done(val title: String, val results: List<ProviderResult>, val messageCount: Int) : BackupState()
    data class Failed(val message: String) : BackupState()
}

object CloudBackup {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<BackupState>(BackupState.Idle)
    val state: StateFlow<BackupState> = _state

    /** Lance une sauvegarde vers tous les hébergeurs activés (survit à la navigation dans l'appli). */
    fun runNow(ctx: Context) {
        if (_state.value is BackupState.Running) return
        val app = ctx.applicationContext
        scope.launch {
            try {
                backupToAll(app) { _state.value = BackupState.Running(it) }
            } catch (e: Exception) {
                _state.value = BackupState.Failed(e.message ?: "Erreur inconnue")
            }
        }
    }

    fun reset() {
        if (_state.value !is BackupState.Running) _state.value = BackupState.Idle
    }

    /** Sauvegarde chiffrée vers chaque hébergeur configuré, en parallèle. */
    suspend fun backupToAll(ctx: Context, onStep: (String) -> Unit = {}): BackupState.Done = coroutineScope {
        val prefs = AppPrefs(ctx)
        val pass = prefs.backupPassphrase() ?: throw IllegalStateException("Définissez d'abord une phrase secrète de chiffrement")
        val targets = CloudStore.all(ctx).filter { it.enabled && it.isComplete }
        if (targets.isEmpty()) throw IllegalStateException("Aucun hébergeur cloud activé et configuré")

        onStep("Lecture et chiffrement des messages…")
        val blob = withContext(Dispatchers.IO) { BackupManager(ctx).createEncrypted(pass) }
        pass.fill('\u0000')

        onStep("Envoi vers ${targets.size} hébergeur(s)…")
        val retention = prefs.backupRetention
        val results = targets.map { cfg ->
            async(Dispatchers.IO) {
                try {
                    val backend = CloudBackend.create(cfg)
                    backend.upload(blob.name, blob.data)
                    val pruned = applyRetention(backend, retention)
                    val msg = "Envoyé (${blob.data.size / 1024} Ko)" + if (pruned > 0) ", $pruned ancienne(s) supprimée(s)" else ""
                    CloudStore.recordResult(ctx, cfg.providerId, true, msg)
                    ProviderResult(cfg.providerId, true, msg)
                } catch (e: Exception) {
                    val msg = e.message ?: e.javaClass.simpleName
                    CloudStore.recordResult(ctx, cfg.providerId, false, msg)
                    ProviderResult(cfg.providerId, false, msg)
                }
            }
        }.awaitAll()

        val okCount = results.count { it.ok }
        val title = "Sauvegarde : $okCount/${results.size} hébergeur(s) OK · ${blob.messageCount} SMS"
        prefs.lastBackupAt = System.currentTimeMillis()
        prefs.lastBackupSummary = title
        val done = BackupState.Done(title, results, blob.messageCount)
        _state.value = done
        done
    }

    /** Ne conserve que les `keep` sauvegardes les plus récentes chez un hébergeur. */
    private fun applyRetention(backend: CloudBackend, keep: Int): Int {
        if (keep <= 0) return 0
        val files = backend.list().filter { it.name.startsWith("semaphore-") && it.name.endsWith(".semb") }
            .sortedByDescending { it.name }
        var removed = 0
        files.drop(keep).forEach {
            try {
                backend.delete(it.key); removed++
            } catch (e: Exception) {
            }
        }
        return removed
    }

    fun listBackups(ctx: Context, providerId: String): List<RemoteFile> {
        val backend = CloudBackend.create(CloudStore.load(ctx, providerId))
        return backend.list().filter { it.name.endsWith(".semb") }.sortedByDescending { it.name }
    }

    fun restoreFrom(ctx: Context, providerId: String, file: RemoteFile, passphrase: CharArray): RestoreResult {
        val backend = CloudBackend.create(CloudStore.load(ctx, providerId))
        val data = backend.download(file.key)
        return BackupManager(ctx).restore(data, passphrase)
    }

    /** Envoie un petit fichier de test puis le supprime. */
    fun testConnection(ctx: Context, providerId: String): String {
        val backend = CloudBackend.create(CloudStore.load(ctx, providerId))
        val name = ".semaphore-test-${System.currentTimeMillis()}"
        backend.upload(name, "Sémaphore : test de connexion".toByteArray())
        val listed = backend.list().any { it.name == name }
        backend.list().filter { it.name == name }.forEach { backend.delete(it.key) }
        return if (listed) "Connexion réussie : écriture, lecture de la liste et suppression OK"
        else "Écriture OK, mais le fichier n'apparaît pas dans la liste (vérifiez le préfixe/droits « List »)"
    }

    fun notifyResult(ctx: Context, done: BackupState.Done) {
        val failed = done.results.filter { !it.ok }
        val text = if (failed.isEmpty()) "Toutes les copies chiffrées ont été envoyées."
        else "Échecs : " + failed.joinToString(" · ") { (com.semaphore.sms.cloud.CloudProviders.byId(it.providerId)?.company ?: it.providerId) + " (" + it.message + ")" }
        Notifications.showBackupResult(ctx, done.title, text)
    }
}
