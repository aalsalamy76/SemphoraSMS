package com.semaphore.sms.crypto

import android.content.Context
import com.semaphore.sms.prefs.AppPrefs
import org.json.JSONArray
import org.json.JSONObject
import java.security.PrivateKey
import java.util.concurrent.ConcurrentHashMap

/** Gestion de l'identité E2E de l'appareil et des clés des contacts. */
object E2E {
    private const val PRIV = "id_priv"
    private const val PUB = "id_pub"
    private const val LEGACY = "legacy_ids"

    private class Identity(val priv: PrivateKey, val pub: ByteArray) {
        val id: String = E2ECore.b64(pub)
    }

    @Volatile private var current: Identity? = null
    @Volatile private var legacyCache: List<Identity>? = null
    private val sessionKeys = ConcurrentHashMap<String, ByteArray>()

    /** Clé d'annuaire normalisée pour un numéro (les 9 derniers chiffres, ou l'expéditeur alphanumérique). */
    fun numberKey(address: String): String {
        val digits = address.filter { it.isDigit() }
        return if (digits.length >= 6) digits.takeLast(9) else address.trim().lowercase()
    }

    @Synchronized
    fun ensureIdentity(ctx: Context) {
        if (current != null) return
        val prefs = AppPrefs(ctx)
        val privEnc = prefs.getRaw(PRIV)
        val pubB64 = prefs.getRaw(PUB)
        if (privEnc != null && pubB64 != null) {
            try {
                current = Identity(E2ECore.decodePrivate(KeyVault.decrypt(privEnc)), E2ECore.unb64(pubB64))
                return
            } catch (e: Exception) {
                // Coffre réinitialisé (restauration d'appareil…) : on régénère.
            }
        }
        generate(ctx)
    }

    /** Nouvelle identité. L'ancienne est conservée pour relire les anciens messages (jamais pour envoyer). */
    @Synchronized
    fun regenerateIdentity(ctx: Context) {
        ensureIdentity(ctx)
        current?.let { addLegacy(ctx, E2ECore.b64(it.priv.encoded), it.id) }
        generate(ctx)
        AppPrefs(ctx).resetAllKeySent()
    }

    private fun generate(ctx: Context) {
        val kp = E2ECore.generateKeyPair()
        val prefs = AppPrefs(ctx)
        prefs.putRaw(PRIV, KeyVault.encrypt(kp.private.encoded))
        prefs.putRaw(PUB, E2ECore.b64(kp.public.encoded))
        current = Identity(kp.private, kp.public.encoded)
        sessionKeys.clear()
    }

    private fun me(ctx: Context): Identity {
        ensureIdentity(ctx)
        return current!!
    }

    // ---------- anciennes identités (lecture seule) ----------

    private fun legacy(ctx: Context): List<Identity> {
        legacyCache?.let { return it }
        val list = ArrayList<Identity>()
        try {
            val raw = AppPrefs(ctx).getSecret(LEGACY)
            if (raw != null) {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(Identity(E2ECore.decodePrivate(E2ECore.unb64(o.getString("priv"))), E2ECore.unb64(o.getString("pub"))))
                }
            }
        } catch (e: Exception) {
        }
        legacyCache = list
        return list
    }

    @Synchronized
    private fun addLegacy(ctx: Context, privB64: String, pubB64: String) {
        if (current?.id == pubB64) return
        val prefs = AppPrefs(ctx)
        val arr = try {
            JSONArray(prefs.getSecret(LEGACY) ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("pub") == pubB64) return
        arr.put(JSONObject().put("priv", privB64).put("pub", pubB64))
        prefs.putSecret(LEGACY, arr.toString())
        legacyCache = null
    }

    // ---------- export / import pour les sauvegardes chiffrées ----------

    /** Identité actuelle + clés des contacts, pour la sauvegarde (protégée par la phrase secrète). */
    fun exportKeys(ctx: Context): JSONObject {
        val i = me(ctx)
        val peers = JSONObject()
        AppPrefs(ctx).allPeerKeys().forEach { (k, v) -> peers.put(k, v) }
        val legacyArr = JSONArray()
        legacy(ctx).forEach { legacyArr.put(JSONObject().put("priv", E2ECore.b64(it.priv.encoded)).put("pub", it.id)) }
        return JSONObject()
            .put("priv", E2ECore.b64(i.priv.encoded))
            .put("pub", i.id)
            .put("legacy", legacyArr)
            .put("peers", peers)
    }

    /** Importe les clés d'une sauvegarde : anciennes identités en lecture seule, clés de contacts manquantes. */
    fun importKeys(ctx: Context, o: JSONObject) {
        ensureIdentity(ctx)
        try {
            addLegacy(ctx, o.getString("priv"), o.getString("pub"))
        } catch (e: Exception) {
        }
        o.optJSONArray("legacy")?.let { arr ->
            for (i in 0 until arr.length()) {
                try {
                    val l = arr.getJSONObject(i)
                    addLegacy(ctx, l.getString("priv"), l.getString("pub"))
                } catch (e: Exception) {
                }
            }
        }
        val prefs = AppPrefs(ctx)
        o.optJSONObject("peers")?.let { peers ->
            val names = peers.keys()
            while (names.hasNext()) {
                val nk = names.next()
                if (prefs.peerKey(nk) == null) prefs.setPeerKey(nk, peers.getString(nk))
            }
        }
        sessionKeys.clear()
    }

    // ---------- usage ----------

    fun myPublicKey(ctx: Context): ByteArray = me(ctx).pub

    fun myFingerprint(ctx: Context): String = E2ECore.fingerprint(myPublicKey(ctx))

    fun keyMessage(ctx: Context): String = E2ECore.keyMessage(myPublicKey(ctx))

    private fun sessionKey(identity: Identity, peerB64: String): ByteArray? {
        val cacheKey = identity.id + "|" + peerB64
        sessionKeys[cacheKey]?.let { return it }
        return try {
            val k = E2ECore.deriveKey(identity.priv, identity.pub, E2ECore.unb64(peerB64))
            sessionKeys[cacheKey] = k
            k
        } catch (e: Exception) {
            null
        }
    }

    /** Le chiffrement est-il actif pour ce correspondant ? */
    fun isActive(ctx: Context, address: String): Boolean {
        val nk = numberKey(address)
        val prefs = AppPrefs(ctx)
        return prefs.peerKey(nk) != null && prefs.e2eEnabled(nk)
    }

    fun keyChangedUnverified(ctx: Context, address: String): Boolean =
        AppPrefs(ctx).keyChanged(numberKey(address))

    fun encryptFor(ctx: Context, address: String, plain: String): String? {
        val peer = AppPrefs(ctx).peerKey(numberKey(address)) ?: return null
        val key = sessionKey(me(ctx), peer) ?: return null
        return E2ECore.encrypt(key, plain)
    }

    /** Déchiffre un message échangé avec `address` (clé actuelle puis anciennes, des deux côtés). */
    fun decryptFrom(ctx: Context, address: String, body: String): String? {
        val nk = numberKey(address)
        val prefs = AppPrefs(ctx)
        val peers = listOfNotNull(prefs.peerKey(nk)) + prefs.peerKeyHistory(nk)
        val identities = listOf(me(ctx)) + legacy(ctx)
        for (identity in identities) {
            for (peer in peers) {
                val key = sessionKey(identity, peer) ?: continue
                E2ECore.decrypt(key, body)?.let { return it }
            }
        }
        return null
    }

    fun safetyNumber(ctx: Context, address: String): String? {
        val peer = AppPrefs(ctx).peerKey(numberKey(address)) ?: return null
        return E2ECore.safetyNumber(myPublicKey(ctx), E2ECore.unb64(peer))
    }

    /** Texte lisible pour l'affichage d'un corps de SMS (déchiffrement transparent). */
    fun displayText(ctx: Context, address: String, body: String?): DisplayText {
        val b = body ?: ""
        return when {
            E2ECore.isKeyMessage(b) -> DisplayText("🔑 Clé de chiffrement échangée", encrypted = false, keyExchange = true, failed = false)
            E2ECore.isEncrypted(b) -> {
                val plain = decryptFrom(ctx, address, b)
                if (plain != null) DisplayText(plain, encrypted = true, keyExchange = false, failed = false)
                else DisplayText("🔒 Message chiffré illisible (clé inconnue ou modifiée)", encrypted = true, keyExchange = false, failed = true)
            }
            else -> DisplayText(b, encrypted = false, keyExchange = false, failed = false)
        }
    }
}

data class DisplayText(
    val text: String,
    val encrypted: Boolean,
    val keyExchange: Boolean,
    val failed: Boolean,
)
