package com.semaphore.sms.sms

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.data.Sms
import com.semaphore.sms.data.SmsRepository

object SmsSender {
    const val ACTION_SENT = "com.semaphore.sms.action.SENT"
    const val ACTION_DELIVERED = "com.semaphore.sms.action.DELIVERED"

    sealed class Result {
        data class Ok(val uri: Uri?, val encrypted: Boolean) : Result()
        data class Error(val message: String) : Result()
    }

    @Suppress("DEPRECATION")
    fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
        else SmsManager.getDefault()

    /**
     * Envoie un SMS. Si le correspondant utilise Sémaphore et que sa clé est connue,
     * le message est chiffré de bout en bout (sauf si `allowEncryption` est faux).
     */
    fun send(context: Context, address: String, text: String, allowEncryption: Boolean = true): Result {
        val ctx = context.applicationContext
        if (address.isBlank()) return Result.Error("Destinataire manquant")
        if (text.isBlank()) return Result.Error("Message vide")
        // Clé du contact modifiée et non vérifiée : on refuse d'envoyer (ni chiffré vers une clé
        // potentiellement usurpée, ni en clair à l'insu de l'utilisateur).
        if (allowEncryption && E2E.isActive(ctx, address) && E2E.keyChangedUnverified(ctx, address)) {
            return Result.Error("La clé de sécurité de ce contact a changé : vérifiez-la avant d'envoyer")
        }
        val encrypt = allowEncryption && E2E.isActive(ctx, address)
        val payload = if (encrypt) {
            E2E.encryptFor(ctx, address, text) ?: return Result.Error("Chiffrement impossible : clé du contact invalide")
        } else text
        return sendRaw(ctx, address, payload, encrypt)
    }

    /** Envoie un contenu tel quel (utilisé aussi pour l'échange de clés). */
    fun sendRaw(context: Context, address: String, payload: String, encrypted: Boolean = false): Result {
        val ctx = context.applicationContext
        val repo = SmsRepository(ctx)
        val uri = repo.insertOutgoing(address, payload)
        return try {
            val sm = smsManager(ctx)
            val parts = sm.divideMessage(payload)
            val sent = ArrayList<PendingIntent>()
            val delivered = ArrayList<PendingIntent>()
            for (i in parts.indices) {
                sent.add(statusIntent(ctx, ACTION_SENT, uri, i))
                delivered.add(statusIntent(ctx, ACTION_DELIVERED, uri, i))
            }
            if (parts.size <= 1) {
                sm.sendTextMessage(address, null, payload, sent.firstOrNull(), delivered.firstOrNull())
            } else {
                sm.sendMultipartTextMessage(address, null, parts, sent, delivered)
            }
            Result.Ok(uri, encrypted)
        } catch (e: Exception) {
            uri?.let { repo.setType(it, Sms.TYPE_FAILED) }
            Result.Error(e.message ?: "Échec de l'envoi")
        }
    }

    private fun statusIntent(ctx: Context, action: String, uri: Uri?, part: Int): PendingIntent {
        val intent = Intent(ctx, SmsStatusReceiver::class.java)
            .setAction(action)
            .setData(uri ?: Uri.parse("sms:unknown"))
            .putExtra("part", part)
        // Mutable : le système doit pouvoir joindre le PDU d'accusé de réception (intent explicite).
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(ctx, part, intent, flags)
    }

    /** Renvoie un message en échec. */
    fun resend(context: Context, messageUri: Uri, address: String, rawBody: String): Result {
        val ctx = context.applicationContext
        try {
            ctx.contentResolver.delete(messageUri, null, null)
        } catch (e: Exception) {
        }
        return sendRaw(ctx, address, rawBody)
    }
}
