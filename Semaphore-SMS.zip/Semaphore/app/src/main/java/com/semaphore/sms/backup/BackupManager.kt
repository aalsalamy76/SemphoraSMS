package com.semaphore.sms.backup

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import com.semaphore.sms.crypto.BackupCrypto
import com.semaphore.sms.crypto.E2E
import org.json.JSONObject
import com.semaphore.sms.data.Sms
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

data class BackupBlob(val name: String, val data: ByteArray, val messageCount: Int)
data class RestoreResult(val inserted: Int, val skipped: Int)

/**
 * Création et restauration des sauvegardes.
 * Contenu : tous les SMS (expéditeur, texte, dates, type, état de lecture) et les clés E2E,
 * en JSON compressé, puis chiffré par [BackupCrypto] avant de quitter le téléphone.
 */
class BackupManager(context: Context) {
    private val ctx = context.applicationContext
    private val cr = ctx.contentResolver

    fun newFileName(): String =
        "semaphore-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".semb"

    fun createEncrypted(passphrase: CharArray): BackupBlob {
        val raw = ByteArrayOutputStream()
        var count = 0
        GZIPOutputStream(raw).use { gz ->
            val w = JsonWriter(OutputStreamWriter(gz, Charsets.UTF_8))
            w.beginObject()
            w.name("app").value("Semaphore")
            w.name("format").value(1)
            w.name("created").value(System.currentTimeMillis())
            w.name("device").value("${Build.MANUFACTURER} ${Build.MODEL}")
            w.name("sms").beginArray()
            cr.query(
                Sms.SMS,
                arrayOf("address", "body", "date", "date_sent", "type", "read", "status"),
                null, null, "date ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(4)
                    if (type == Sms.TYPE_DRAFT) continue
                    w.beginObject()
                    w.name("a").value(c.getString(0) ?: "")
                    w.name("b").value(c.getString(1) ?: "")
                    w.name("d").value(c.getLong(2))
                    w.name("ds").value(c.getLong(3))
                    w.name("t").value(type)
                    w.name("r").value(c.getInt(5))
                    w.name("s").value(c.getInt(6))
                    w.endObject()
                    count++
                }
            }
            w.endArray()
            // Clés E2E (identité + contacts) pour relire les SMS chiffrés après restauration.
            // Elles sont protégées comme le reste du fichier par la phrase secrète.
            try {
                w.name("e2e").value(E2E.exportKeys(ctx).toString())
            } catch (e: Exception) {
            }
            w.endObject()
            w.flush()
        }
        val encrypted = BackupCrypto.encrypt(raw.toByteArray(), passphrase)
        return BackupBlob(newFileName(), encrypted, count)
    }

    /** Restaure une sauvegarde chiffrée (nécessite d'être l'application SMS par défaut). Ignore les doublons. */
    fun restore(encrypted: ByteArray, passphrase: CharArray, onProgress: (Int) -> Unit = {}): RestoreResult {
        val plain = BackupCrypto.decrypt(encrypted, passphrase)

        val existing = HashSet<String>()
        cr.query(Sms.SMS, arrayOf("date", "address", "body"), null, null, null)?.use { c ->
            while (c.moveToNext()) existing.add(signature(c.getLong(0), c.getString(1), c.getString(2)))
        }

        var inserted = 0
        var skipped = 0
        val batch = ArrayList<ContentValues>()
        fun flush() {
            if (batch.isEmpty()) return
            inserted += cr.bulkInsert(Sms.SMS, batch.toTypedArray())
            batch.clear()
            onProgress(inserted)
        }

        JsonReader(InputStreamReader(GZIPInputStream(ByteArrayInputStream(plain)), Charsets.UTF_8)).use { r ->
            r.beginObject()
            while (r.hasNext()) {
                val field = r.nextName()
                if (field == "e2e" && r.peek() == JsonToken.STRING) {
                    try {
                        E2E.importKeys(ctx, JSONObject(r.nextString()))
                    } catch (e: Exception) {
                    }
                    continue
                }
                if (field != "sms") {
                    r.skipValue(); continue
                }
                r.beginArray()
                while (r.hasNext()) {
                    var a = ""; var b = ""; var d = 0L; var ds = 0L; var t = Sms.TYPE_INBOX; var rd = 1; var s = -1
                    r.beginObject()
                    while (r.hasNext()) {
                        val n = r.nextName()
                        if (r.peek() == JsonToken.NULL) {
                            r.nextNull(); continue
                        }
                        when (n) {
                            "a" -> a = r.nextString()
                            "b" -> b = r.nextString()
                            "d" -> d = r.nextLong()
                            "ds" -> ds = r.nextLong()
                            "t" -> t = r.nextInt()
                            "r" -> rd = r.nextInt()
                            "s" -> s = r.nextInt()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (a.isBlank() || !existing.add(signature(d, a, b))) {
                        skipped++
                        continue
                    }
                    batch.add(ContentValues().apply {
                        put("address", a); put("body", b); put("date", d); put("date_sent", ds)
                        put("type", t); put("read", rd); put("seen", 1); put("status", s)
                    })
                    if (batch.size >= 250) flush()
                }
                r.endArray()
            }
            r.endObject()
        }
        flush()
        return RestoreResult(inserted, skipped)
    }

    private fun signature(date: Long, address: String?, body: String?): String =
        "$date|${address ?: ""}|${(body ?: "").hashCode()}"
}
