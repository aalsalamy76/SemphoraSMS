package com.semaphore.sms.ui

import android.net.Uri
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

/** Demande de navigation venant de l'extérieur (notification, lien sms:, partage). */
sealed class NavRequest {
    data class Thread(val threadId: Long, val address: String, val text: String = "") : NavRequest()
    data class Compose(val to: String, val text: String) : NavRequest()
    data object Backup : NavRequest()
}

private fun threadRoute(threadId: Long, address: String, text: String = "") =
    "thread/$threadId?address=${Uri.encode(address)}&text=${Uri.encode(text)}"

@Composable
fun AppNav(
    pending: NavRequest?,
    onPendingConsumed: () -> Unit,
    onRequestDefault: () -> Unit,
) {
    val nav: NavHostController = rememberNavController()

    LaunchedEffect(pending) {
        when (val p = pending) {
            is NavRequest.Thread -> nav.navigate(threadRoute(p.threadId, p.address, p.text)) { launchSingleTop = true }
            is NavRequest.Compose -> nav.navigate("new?to=${Uri.encode(p.to)}&text=${Uri.encode(p.text)}") { launchSingleTop = true }
            NavRequest.Backup -> nav.navigate("backup") { launchSingleTop = true }
            null -> return@LaunchedEffect
        }
        onPendingConsumed()
    }

    NavHost(
        navController = nav,
        startDestination = "home",
        enterTransition = { slideInHorizontally { it / 4 } + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally { it / 4 } + fadeOut() },
    ) {
        composable("home") {
            ConversationsScreen(
                onOpen = { id, addr -> nav.navigate(threadRoute(id, addr)) },
                onNew = { nav.navigate("new?to=&text=") },
                onSettings = { nav.navigate("settings") },
                onRequestDefault = onRequestDefault,
            )
        }
        composable(
            "thread/{threadId}?address={address}&text={text}",
            arguments = listOf(
                navArgument("threadId") { type = NavType.LongType },
                navArgument("address") { type = NavType.StringType; defaultValue = "" },
                navArgument("text") { type = NavType.StringType; defaultValue = "" },
            ),
        ) { entry ->
            val args = entry.arguments
            ThreadScreen(
                threadId = args?.getLong("threadId") ?: 0L,
                address = args?.getString("address") ?: "",
                initialText = args?.getString("text") ?: "",
                onBack = { if (!nav.popBackStack()) nav.navigate("home") },
            )
        }
        composable(
            "new?to={to}&text={text}",
            arguments = listOf(
                navArgument("to") { type = NavType.StringType; defaultValue = "" },
                navArgument("text") { type = NavType.StringType; defaultValue = "" },
            ),
        ) { entry ->
            val text = entry.arguments?.getString("text") ?: ""
            NewMessageScreen(
                initialTo = entry.arguments?.getString("to") ?: "",
                onBack = { nav.popBackStack() },
                onOpenThread = { tid, addr ->
                    nav.navigate(threadRoute(tid, addr, text)) {
                        popUpTo("home")
                    }
                },
            )
        }
        composable("settings") {
            SettingsScreen(
                onBack = { nav.popBackStack() },
                onBackup = { nav.navigate("backup") },
                onScheduled = { nav.navigate("scheduled") },
                onRequestDefault = onRequestDefault,
            )
        }
        composable("backup") {
            BackupScreen(
                onBack = { if (!nav.popBackStack()) nav.navigate("home") },
                onProvider = { id -> nav.navigate("provider/$id") },
            )
        }
        composable("provider/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            ProviderScreen(providerId = entry.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
        }
        composable("scheduled") {
            ScheduledScreen(onBack = { nav.popBackStack() })
        }
    }
}
