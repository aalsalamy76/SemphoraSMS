package com.semaphore.sms.ui

import android.app.Application
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.SmsMessage
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.semaphore.sms.UiState
import com.semaphore.sms.crypto.E2E
import com.semaphore.sms.crypto.E2ECore
import com.semaphore.sms.data.Message
import com.semaphore.sms.data.MsgStatus
import com.semaphore.sms.data.SmsRepository
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.sms.ScheduledSendWorker
import com.semaphore.sms.sms.SmsSender
import com.semaphore.sms.ui.theme.SecureColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreadScreen(threadId: Long, address: String, initialText: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as Application
    val vm: ThreadViewModel = viewModel(key = "thread_${threadId}_$address") { ThreadViewModel(app, threadId, address) }
    val messages by vm.messages.collectAsStateWithLifecycle()
    val title by vm.title.collectAsStateWithLifecycle()
    val photo by vm.photo.collectAsStateWithLifecycle()
    val addresses by vm.addresses.collectAsStateWithLifecycle()
    val e2e by vm.e2e.collectAsStateWithLifecycle()
    val scheduled by vm.scheduled.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    var text by rememberSaveable { mutableStateOf(initialText) }
    var menu by remember { mutableStateOf(false) }
    var showE2E by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf<Message?>(null) }

    val main = addresses.firstOrNull() ?: address
    val isGroup = addresses.size > 1
    val encrypting = e2e.peerKnown && e2e.enabled && !isGroup

    LaunchedEffect(UiState.refreshTick) { vm.reload(immediate = true) }
    LaunchedEffect(messages.firstOrNull()?.id) { if (messages.isNotEmpty()) listState.animateScrollToItem(0) }

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun send() {
        val body = text.trim()
        if (body.isEmpty() || main.isBlank()) return
        if (encrypting && e2e.keyChanged) {
            // Clé modifiée : l'utilisateur doit d'abord vérifier le numéro de sécurité.
            showE2E = true
            return
        }
        text = ""
        scope.launch {
            val r = withContext(Dispatchers.IO) { SmsSender.send(ctx, main, body, allowEncryption = encrypting) }
            if (r is SmsSender.Result.Error) {
                text = body
                toast("Envoi impossible : ${r.message}")
            }
            vm.reload(immediate = true)
        }
    }

    fun schedule(at: Long) {
        val body = text.trim()
        if (body.isEmpty() || main.isBlank()) return
        ScheduledSendWorker.schedule(ctx, main, body, at)
        text = ""
        vm.refreshScheduled()
        toast("Message programmé pour ${Fmt.full(at)}")
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(title, photo, size = 38.dp, group = isGroup)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (encrypting) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Lock, null, tint = SecureColors.lockGreen, modifier = Modifier.size(12.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Chiffré de bout en bout", style = MaterialTheme.typography.labelSmall, color = SecureColors.lockGreen)
                                }
                            } else if (!isGroup && title != com.semaphore.sms.data.Contacts.formatNumber(main)) {
                                Text(
                                    com.semaphore.sms.data.Contacts.formatNumber(main),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (!isGroup && main.any { it.isDigit() }) {
                        IconButton(onClick = {
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(main))))
                            } catch (e: Exception) {
                            }
                        }) { Icon(Icons.Filled.Call, contentDescription = "Appeler") }
                    }
                    if (!isGroup) {
                        IconButton(onClick = { vm.refreshE2E(); showE2E = true }) {
                            Icon(
                                if (encrypting) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                contentDescription = "Chiffrement",
                                tint = if (encrypting) SecureColors.lockGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Plus") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (!isGroup) DropdownMenuItem(
                                text = { Text("Chiffrement de bout en bout") },
                                leadingIcon = { Icon(Icons.Filled.Lock, null) },
                                onClick = { menu = false; vm.refreshE2E(); showE2E = true },
                            )
                            DropdownMenuItem(
                                text = { Text("Numéros bloqués…") },
                                leadingIcon = { Icon(Icons.Filled.Block, null) },
                                onClick = {
                                    menu = false
                                    try {
                                        val tm = ctx.getSystemService(android.telecom.TelecomManager::class.java)
                                        ctx.startActivity(tm.createManageBlockedNumbersIntent())
                                    } catch (e: Exception) {
                                        toast("Disponible uniquement quand Sémaphore est l'application SMS par défaut")
                                    }
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Supprimer la conversation") },
                                leadingIcon = { Icon(Icons.Filled.Delete, null) },
                                onClick = { menu = false; confirmDelete = true },
                            )
                        }
                    }
                },
            )
        },
        bottomBar = {
            Column(Modifier.navigationBarsPadding().imePadding()) {
                if (e2e.keyChanged && !isGroup) KeyChangedBanner(onReview = { vm.refreshE2E(); showE2E = true })
                scheduled.forEach { s ->
                    ScheduledChip(s.body, s.at, onCancel = {
                        ScheduledSendWorker.cancel(ctx, s.id)
                        vm.refreshScheduled()
                    })
                }
                if (isGroup) {
                    Text(
                        "Les conversations de groupe (MMS) sont en lecture seule dans cette version.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                    )
                } else {
                    Composer(
                        text = text,
                        onText = { text = it },
                        encrypting = encrypting,
                        onSend = { send() },
                        onSchedule = { at -> schedule(at) },
                    )
                }
            }
        },
    ) { pad ->
        LazyColumn(
            state = listState,
            reverseLayout = true,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 8.dp,
                start = 12.dp, end = 12.dp,
            ),
        ) {
            itemsIndexed(messages, key = { _, m -> (if (m.isMms) "m" else "s") + m.id }) { i, m ->
                val older = messages.getOrNull(i + 1)
                val newer = messages.getOrNull(i - 1)
                val showDay = older == null || !Fmt.isSameDay(older.date, m.date)
                val groupedWithNewer = newer != null && newer.outgoing == m.outgoing && newer.date - m.date < 120_000 &&
                    Fmt.isSameDay(newer.date, m.date)
                Column {
                    if (showDay) DayChip(Fmt.day(m.date))
                    MessageBubble(
                        m = m,
                        compactBottom = groupedWithNewer,
                        onCopy = {
                            clipboardCopy(ctx, m.text)
                            toast("Copié")
                        },
                        onShare = {
                            ctx.startActivity(
                                Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.text), "Partager")
                            )
                        },
                        onDelete = {
                            scope.launch {
                                withContext(Dispatchers.IO) { SmsRepository(ctx).deleteMessage(m) }
                                vm.reload(immediate = true)
                            }
                        },
                        onResend = {
                            scope.launch {
                                withContext(Dispatchers.IO) { SmsSender.resend(ctx, m.uri, main, m.rawBody) }
                                vm.reload(immediate = true)
                            }
                        },
                        onDetails = { details = m },
                    )
                }
            }
        }
    }

    if (showE2E && !isGroup) {
        E2EDialog(
            info = e2e,
            name = title,
            onDismiss = { showE2E = false },
            onSendKey = {
                scope.launch {
                    withContext(Dispatchers.IO) {
                        SmsSender.sendRaw(ctx, main, E2E.keyMessage(ctx))
                        AppPrefs(ctx).setKeySent(E2E.numberKey(main), true)
                    }
                    toast("Clé envoyée. Le chiffrement s'activera dès la réponse automatique du contact.")
                    vm.reload(immediate = true)
                }
                showE2E = false
            },
            onToggle = { enabled ->
                AppPrefs(ctx).setE2eEnabled(E2E.numberKey(main), enabled)
                vm.refreshE2E()
            },
            onVerified = {
                val nk = E2E.numberKey(main)
                AppPrefs(ctx).setKeyVerified(nk, true)
                AppPrefs(ctx).setKeyChanged(nk, false)
                vm.refreshE2E()
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer la conversation ?") },
            text = { Text("Les messages seront supprimés de ce téléphone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch {
                        withContext(Dispatchers.IO) { SmsRepository(ctx).deleteThread(vm.threadId) }
                        onBack()
                    }
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } },
        )
    }

    details?.let { m ->
        AlertDialog(
            onDismissRequest = { details = null },
            icon = { Icon(Icons.Filled.Info, null) },
            title = { Text("Détails du message") },
            text = {
                Column {
                    Text((if (m.outgoing) "Envoyé à " else "Reçu de ") + com.semaphore.sms.data.Contacts.formatNumber(m.address))
                    Text(Fmt.full(m.date))
                    Text(
                        "État : " + when (m.status) {
                            MsgStatus.RECEIVED -> "reçu"
                            MsgStatus.SENDING -> "en cours d'envoi"
                            MsgStatus.SENT -> "envoyé"
                            MsgStatus.DELIVERED -> "distribué"
                            MsgStatus.FAILED -> "échec"
                        }
                    )
                    Text(if (m.encrypted) "🔒 Chiffré de bout en bout (AES-256-GCM)" else "Non chiffré (SMS standard)")
                    if (m.isMms) Text("Type : MMS")
                }
            },
            confirmButton = { TextButton(onClick = { details = null }) { Text("OK") } },
        )
    }
}

private fun clipboardCopy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(android.content.ClipboardManager::class.java) ?: return
    cm.setPrimaryClip(android.content.ClipData.newPlainText("message", text))
}

@Composable
private fun DayChip(label: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    m: Message,
    compactBottom: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onResend: () -> Unit,
    onDetails: () -> Unit,
) {
    if (m.keyExchange) {
        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(SecureColors.lockGreen.copy(alpha = 0.12f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.VerifiedUser, null, tint = SecureColors.lockGreen, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    if (m.outgoing) "Vous avez partagé votre clé de chiffrement · ${Fmt.time(m.date)}"
                    else "Clé de chiffrement du contact reçue · ${Fmt.time(m.date)}",
                    style = MaterialTheme.typography.labelSmall, color = SecureColors.lockGreen,
                )
            }
        }
        return
    }

    var menu by remember { mutableStateOf(false) }
    val out = m.outgoing
    val bg = when {
        m.status == MsgStatus.FAILED -> MaterialTheme.colorScheme.errorContainer
        out -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val fg = when {
        m.status == MsgStatus.FAILED -> MaterialTheme.colorScheme.onErrorContainer
        out -> MaterialTheme.colorScheme.onPrimary
        else -> MaterialTheme.colorScheme.onSurface
    }
    val big = 20.dp
    val small = 6.dp
    // Petite « queue » du côté de l'expéditeur.
    val shape = if (out) RoundedCornerShape(topStart = big, topEnd = big, bottomEnd = small, bottomStart = big)
    else RoundedCornerShape(topStart = big, topEnd = big, bottomEnd = big, bottomStart = small)

    Row(
        Modifier.fillMaxWidth().padding(top = if (compactBottom) 1.dp else 3.dp, bottom = 1.dp),
        horizontalArrangement = if (out) Arrangement.End else Arrangement.Start,
    ) {
        Box {
            Column(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(shape)
                    .background(bg)
                    .combinedClickable(onClick = { if (m.status == MsgStatus.FAILED) menu = true }, onLongClick = { menu = true })
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                horizontalAlignment = if (out) Alignment.End else Alignment.Start,
            ) {
                m.images.forEach { uri ->
                    MmsImage(uri)
                    Spacer(Modifier.height(6.dp))
                }
                if (m.text.isNotEmpty()) {
                    Text(
                        m.text,
                        color = fg,
                        style = MaterialTheme.typography.bodyLarge,
                        fontStyle = if (m.decryptFailed) FontStyle.Italic else FontStyle.Normal,
                    )
                }
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (m.encrypted) {
                        Icon(Icons.Filled.Lock, "Chiffré", tint = fg.copy(alpha = 0.75f), modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(3.dp))
                    }
                    Text(Fmt.time(m.date), style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.75f))
                    if (out) {
                        Spacer(Modifier.width(4.dp))
                        val (icon, desc) = when (m.status) {
                            MsgStatus.SENDING -> Icons.Filled.AccessTime to "Envoi…"
                            MsgStatus.SENT -> Icons.Filled.Check to "Envoyé"
                            MsgStatus.DELIVERED -> Icons.Filled.DoneAll to "Distribué"
                            MsgStatus.FAILED -> Icons.Filled.ErrorOutline to "Échec"
                            MsgStatus.RECEIVED -> Icons.Filled.Check to ""
                        }
                        Icon(icon, desc, tint = fg.copy(alpha = 0.85f), modifier = Modifier.size(14.dp))
                    }
                }
                if (m.status == MsgStatus.FAILED) {
                    Text("Non envoyé · touchez pour réessayer", style = MaterialTheme.typography.labelSmall, color = fg)
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (m.status == MsgStatus.FAILED && out) DropdownMenuItem(
                    text = { Text("Renvoyer") }, leadingIcon = { Icon(Icons.Filled.Refresh, null) },
                    onClick = { menu = false; onResend() },
                )
                if (m.text.isNotEmpty()) {
                    DropdownMenuItem(
                        text = { Text("Copier") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) },
                        onClick = { menu = false; onCopy() },
                    )
                    DropdownMenuItem(
                        text = { Text("Partager") }, leadingIcon = { Icon(Icons.Filled.Share, null) },
                        onClick = { menu = false; onShare() },
                    )
                }
                DropdownMenuItem(
                    text = { Text("Détails") }, leadingIcon = { Icon(Icons.Filled.Info, null) },
                    onClick = { menu = false; onDetails() },
                )
                DropdownMenuItem(
                    text = { Text("Supprimer") }, leadingIcon = { Icon(Icons.Filled.Delete, null) },
                    onClick = { menu = false; onDelete() },
                )
            }
        }
    }
}

@Composable
private fun Composer(
    text: String,
    onText: (String) -> Unit,
    encrypting: Boolean,
    onSend: () -> Unit,
    onSchedule: (Long) -> Unit,
) {
    val ctx = LocalContext.current
    var scheduleMenu by remember { mutableStateOf(false) }
    val counter = remember(text, encrypting) { smsCounter(text, encrypting) }

    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                TextField(
                    value = text,
                    onValueChange = onText,
                    placeholder = { Text(if (encrypting) "Message chiffré" else "Message SMS") },
                    leadingIcon = if (encrypting) {
                        { Icon(Icons.Filled.Lock, null, tint = SecureColors.lockGreen) }
                    } else null,
                    maxLines = 6,
                    shape = RoundedCornerShape(26.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(6.dp))
                Box {
                    IconButton(onClick = { scheduleMenu = true }, enabled = text.isNotBlank()) {
                        Icon(Icons.Filled.Schedule, contentDescription = "Programmer l'envoi")
                    }
                    DropdownMenu(expanded = scheduleMenu, onDismissRequest = { scheduleMenu = false }) {
                        presetTimes().forEach { (label, at) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { scheduleMenu = false; onSchedule(at) })
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Choisir la date et l'heure…") },
                            onClick = { scheduleMenu = false; pickDateTime(ctx) { onSchedule(it) } },
                        )
                    }
                }
                FilledIconButton(
                    onClick = onSend,
                    enabled = text.isNotBlank(),
                    modifier = Modifier.size(52.dp),
                    colors = if (encrypting) IconButtonDefaults.filledIconButtonColors(containerColor = SecureColors.lockGreen)
                    else IconButtonDefaults.filledIconButtonColors(),
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer")
                }
            }
            AnimatedVisibility(text.isNotEmpty()) {
                Text(
                    counter,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 18.dp, top = 4.dp),
                )
            }
        }
    }
}

private fun smsCounter(text: String, encrypting: Boolean): String = try {
    val payload = if (encrypting) "A".repeat(E2ECore.encryptedLength(text)) else text
    val r = SmsMessage.calculateLength(payload, false)
    val parts = r[0]
    val remaining = r[2]
    (if (encrypting) "🔒 " else "") + "${text.length} car. · $parts SMS" + if (parts == 1) " · reste $remaining" else ""
} catch (e: Exception) {
    "${text.length} caractères"
}

private fun presetTimes(): List<Pair<String, Long>> {
    val now = Calendar.getInstance()
    val out = ArrayList<Pair<String, Long>>()
    out.add("Dans 1 heure" to now.timeInMillis + 3_600_000L)
    val evening = (now.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 20); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    if (evening.timeInMillis > now.timeInMillis + 600_000L) out.add("Ce soir à 20:00" to evening.timeInMillis)
    val morning = (now.clone() as Calendar).apply {
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    out.add("Demain à 08:00" to morning.timeInMillis)
    return out
}

private fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    DatePickerDialog(ctx, { _, y, mo, d ->
        TimePickerDialog(ctx, { _, h, mi ->
            val c = Calendar.getInstance().apply {
                set(y, mo, d, h, mi, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > System.currentTimeMillis()) onPicked(c.timeInMillis)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).apply {
        datePicker.minDate = now.timeInMillis - 1000
    }.show()
}

@Composable
private fun ScheduledChip(body: String, at: Long, onCancel: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Schedule, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(Fmt.full(at), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Text(body, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
        }
        IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Annuler l'envoi programmé", tint = MaterialTheme.colorScheme.onSecondaryContainer) }
    }
}

@Composable
private fun KeyChangedBanner(onReview: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = SecureColors.warning.copy(alpha = 0.15f)),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Warning, null, tint = SecureColors.warning)
            Spacer(Modifier.width(10.dp))
            Text(
                "La clé de sécurité de ce contact a changé (nouveau téléphone ou réinstallation). Vérifiez-la.",
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onReview) { Text("Vérifier") }
        }
    }
}

@Composable
private fun E2EDialog(
    info: E2EInfo,
    name: String,
    onDismiss: () -> Unit,
    onSendKey: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onVerified: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Lock, null, tint = SecureColors.lockGreen) },
        title = { Text("Chiffrement de bout en bout") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!info.peerKnown) {
                    Text(
                        "Si $name utilise aussi Sémaphore, vos SMS peuvent être chiffrés : seuls vos deux téléphones " +
                            "pourront les lire (ni l'opérateur, ni un tiers)."
                    )
                    Text(
                        "Touchez « Envoyer ma clé » : un SMS d'échange de clé est envoyé, son application répond " +
                            "automatiquement et le chiffrement s'active.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Chiffrer mes messages", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                        Switch(checked = info.enabled, onCheckedChange = onToggle)
                    }
                    if (info.keyChanged) {
                        Text(
                            "⚠️ La clé de ce contact a changé. Comparez le numéro de sécurité avant de continuer.",
                            color = SecureColors.warning, style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Text("Numéro de sécurité", style = MaterialTheme.typography.labelLarge)
                    Text(
                        info.safetyNumber ?: "—",
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "Comparez ce numéro avec celui affiché sur le téléphone de $name (en personne ou par appel). " +
                            "S'ils sont identiques, personne ne s'est interposé.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (info.verified && !info.keyChanged) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VerifiedUser, null, tint = SecureColors.lockGreen, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Vérifié", color = SecureColors.lockGreen, style = MaterialTheme.typography.labelLarge)
                        }
                    } else {
                        OutlinedButton(onClick = onVerified) { Text("Marquer comme vérifié") }
                    }
                }
                HorizontalDivider()
                Text("Votre empreinte : ${info.myFingerprint}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                Text(
                    "Protocole : ECDH P-256 · HKDF-SHA256 · AES-256-GCM. Les SMS chiffrés restent chiffrés dans la base " +
                        "du téléphone et dans les sauvegardes.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            Button(onClick = onSendKey) { Text(if (info.peerKnown) "Renvoyer ma clé" else "Envoyer ma clé") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}
