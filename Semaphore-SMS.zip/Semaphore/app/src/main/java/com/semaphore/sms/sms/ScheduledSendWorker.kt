package com.semaphore.sms.sms

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.semaphore.sms.prefs.AppPrefs
import com.semaphore.sms.prefs.ScheduledMessage
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Envoi différé d'un SMS (messages programmés). */
class ScheduledSendWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val prefs = AppPrefs(applicationContext)
        val workId = this.id.toString()
        // Le texte est conservé chiffré dans le coffre, pas dans les données du Worker.
        val msg = prefs.scheduled().firstOrNull { it.id == workId } ?: return Result.success()
        val r = SmsSender.send(applicationContext, msg.address, msg.body)
        prefs.removeScheduled(workId)
        if (r is SmsSender.Result.Error) {
            Notifications.showInfo(applicationContext, "Message programmé non envoyé", r.message)
        }
        return Result.success()
    }

    companion object {
        const val TAG = "scheduled_sms"

        fun schedule(ctx: Context, address: String, body: String, at: Long): String {
            val delay = (at - System.currentTimeMillis()).coerceAtLeast(0L)
            val req = OneTimeWorkRequestBuilder<ScheduledSendWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf("v" to 1))
                .addTag(TAG)
                .build()
            val id = req.id.toString()
            AppPrefs(ctx).addScheduled(ScheduledMessage(id, address, body, at))
            WorkManager.getInstance(ctx).enqueue(req)
            return id
        }

        fun cancel(ctx: Context, id: String) {
            try {
                WorkManager.getInstance(ctx).cancelWorkById(UUID.fromString(id))
            } catch (e: Exception) {
            }
            AppPrefs(ctx).removeScheduled(id)
        }
    }
}
