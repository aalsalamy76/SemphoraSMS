# Sémaphore — SMS chiffrés et sauvegardes sur 12 clouds

Application SMS Android moderne (Kotlin, Jetpack Compose, Material 3) qui remplace l'application Messages,
chiffre de bout en bout les SMS échangés entre utilisateurs de Sémaphore et sauvegarde vos messages,
chiffrés sur le téléphone, chez 12 hébergeurs cloud.

## Obtenir l'APK

**Option A — Android Studio (le plus simple)**
1. Ouvrez le dossier `Semaphore` dans Android Studio (Ladybug ou plus récent).
2. Laissez Gradle se synchroniser, puis menu **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
3. L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

**Option B — GitHub Actions, sans rien installer** (workflow `.github/workflows/android.yml`)
1. Créez un dépôt GitHub privé et poussez-y ce dossier.
2. L'onglet **Actions** lance automatiquement le workflow « Android » (environ 5 minutes).
3. Téléchargez l'artefact **Semaphore-apk** en bas de la page du run.
4. Pour une version publiée : créez un tag `v1.0.0` (`git tag v1.0.0 && git push --tags`) ; une Release
   GitHub est créée avec les APK attachés.

**APK signé (facultatif)** : générez une clé une fois, puis ajoutez 4 secrets au dépôt
(*Settings › Secrets and variables › Actions*) :
```
keytool -genkeypair -v -keystore semaphore.jks -alias semaphore -keyalg RSA -keysize 4096 -validity 10000
base64 -w0 semaphore.jks      # → secret KEYSTORE_BASE64
```
Secrets : `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (semaphore), `KEY_PASSWORD`.
Gardez `semaphore.jks` en lieu sûr : les mises à jour de l'appli devront être signées avec la même clé.

**Installation sur le téléphone** : copiez l'APK, ouvrez-le et autorisez l'installation depuis cette source.
Au premier lancement, acceptez de faire de Sémaphore l'**application SMS par défaut** (obligatoire sous Android
pour recevoir, écrire et restaurer des SMS).

## Fonctionnalités

**Messagerie**
- Conversations avec photos et noms des contacts, compteur de non-lus, recherche dans contacts et messages
- Bulles modernes, séparateurs de jours, accusés d'envoi et de distribution (✓ / ✓✓), renvoi en cas d'échec
- Compteur de caractères et de SMS, longs messages découpés automatiquement
- Messages programmés (dans 1 h, ce soir, demain, date et heure au choix), annulables
- Notifications avec réponse rapide et « marquer comme lu », option pour masquer le contenu
- Réponse par SMS depuis un appel entrant, partage de texte vers Sémaphore, liens `sms:`
- Blocage des numéros via la liste système Android
- Lecture des MMS existants (texte et images)
- Thème clair / sombre / système, couleurs dynamiques Material You (Android 12+)
- Verrouillage de l'application par empreinte, visage ou code

**Chiffrement de bout en bout (entre deux téléphones équipés de Sémaphore)**
- Identité ECDH P-256 générée sur l'appareil, clé privée protégée par le Keystore Android
- Échange de clés par SMS (`#SEMK1:`), réponse automatique, chiffrement activé ensuite par défaut
- Messages en AES-256-GCM (authentifiés) avec clé dérivée par HKDF-SHA256
- Numéro de sécurité de 30 chiffres à comparer, avertissement et blocage d'envoi si la clé d'un contact change
- Les SMS chiffrés restent chiffrés dans la base du téléphone ; affichage déchiffré à la volée

**Sauvegarde zero-knowledge**
- Chiffrement sur le téléphone avant tout envoi : AES-256-GCM, clé dérivée de votre phrase secrète
  (PBKDF2-SHA256, 310 000 itérations). Les hébergeurs ne voient que des données illisibles.
- Envoi en parallèle vers tous les hébergeurs activés, rapport par hébergeur
- Sauvegarde automatique quotidienne ou hebdomadaire (Wi-Fi uniquement en option), rétention configurable
- Restauration depuis n'importe quel hébergeur ou depuis un fichier local `.semb`, sans doublons
- Les clés E2E sont incluses dans la sauvegarde (protégées par la phrase secrète) pour relire
  vos messages chiffrés sur un nouveau téléphone
- Identifiants cloud chiffrés sur l'appareil (Keystore), jamais en clair

## Les 12 hébergeurs

| Hébergeur | Service | Région préréglée | Protocole |
|---|---|---|---|
| Amazon Web Services | Amazon S3 | Paris (eu-west-3) | S3 SigV4 |
| Microsoft Azure | Blob Storage | au choix | URL SAS |
| Google Cloud | Cloud Storage | auto | S3 (clés HMAC) |
| Alibaba Cloud | OSS | Francfort | S3 compatible |
| Oracle Cloud | OCI Object Storage | Paris (eu-paris-1) | S3 compatible |
| IBM Cloud | Cloud Object Storage | Francfort (eu-de) | S3 (HMAC) |
| Tencent Cloud | COS | Francfort | S3 compatible |
| Huawei Cloud | OBS | Europe (eu-west-101) | S3 compatible |
| OVHcloud 🇫🇷 | Object Storage S3 | Gravelines (gra) | S3 compatible |
| Cloudflare | R2 | auto | S3 compatible |
| Backblaze | B2 | Europe (eu-central-003) | S3 compatible |
| Wasabi | Hot Cloud Storage | Paris (eu-west-2) | S3 compatible |

Les trois premiers sont les leaders mondiaux du cloud (environ 28 %, 20 % et 15 % du marché au 2ᵉ trimestre
2026 selon Synergy Research). Chaque écran d'hébergeur explique où créer les identifiants et propose
un bouton **Tester** (écriture, liste et suppression d'un fichier de test). Tous les champs (point d'accès,
région, adressage) restent modifiables.

## Limites connues (honnêtement)

- **MMS** : la réception de nouveaux MMS (photos, groupes) n'est pas implémentée ; une notification vous
  prévient. Les MMS déjà présents sont affichés. Les conversations de groupe sont en lecture seule.
- **Chiffrement E2E** : il ne fonctionne qu'entre deux téléphones Sémaphore. Avec les autres contacts, les SMS
  restent des SMS classiques (lisibles par l'opérateur). Il n'y a pas de confidentialité persistante
  (« forward secrecy ») comme dans Signal, et l'opérateur voit toujours qui écrit à qui et quand.
- **Sauvegarde** : les SMS sont sauvegardés ; les pièces jointes MMS ne le sont pas.
- **Phrase secrète** : si vous la perdez, vos sauvegardes sont irrécupérables (c'est le principe du zero-knowledge).

## Vérifications effectuées

- Signature AWS SigV4 validée sur les vecteurs de test officiels d'AWS ; HKDF validé sur le RFC 5869.
- Chiffrement E2E et des sauvegardes testés (aller-retour, détection d'altération, mauvaise clé, mauvaise phrase).
- Envoi, liste, téléchargement et suppression testés contre un serveur S3 local qui vérifie les signatures
  (un secret erroné est bien refusé).
- Toute la couche SMS / chiffrement / cloud / sauvegarde compile contre l'API Android 15.
- L'interface Compose n'a pas pu être compilée dans l'environnement de génération : la première
  compilation dans Android Studio ou GitHub Actions confirmera ce point.

## Structure

```
app/src/main/java/com/semaphore/sms/
├── MainActivity.kt          rôle SMS par défaut, permissions, verrouillage, liens entrants
├── SemaphoreApp.kt          initialisation, état partagé de l'interface
├── crypto/                  E2E (ECDH/HKDF/AES-GCM), sauvegardes (PBKDF2/AES-GCM), coffre Keystore
├── sms/                     envoi, réception, accusés, notifications, messages programmés
├── data/                    accès aux SMS/MMS Android, contacts
├── cloud/                   12 hébergeurs, signature SigV4, Azure SAS
├── backup/                  création/restauration, envoi multi-cloud, sauvegarde automatique
├── prefs/                   réglages
└── ui/                      écrans Compose (conversations, discussion, réglages, sauvegarde…)
```
